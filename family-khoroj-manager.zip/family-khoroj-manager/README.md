# পারিবারিক খরচ ম্যানেজার (Family Khoroj Manager)

একটি সম্পূর্ণ অফলাইন-ফার্স্ট পারিবারিক আয়-ব্যয় ব্যবস্থাপনা অ্যাপ। Vanilla HTML5 / CSS3 / JavaScript (ES6+) দিয়ে তৈরি এবং **Capacitor** দিয়ে Android APK হিসেবে প্যাকেজ করা হয়েছে। কোনো বাধ্যতামূলক ব্যাকএন্ড/সার্ভার নেই — সব ডেটা ডিভাইসে **IndexedDB**-তে সংরক্ষিত হয়।

---

## ✨ মূল বৈশিষ্ট্য

- সদস্য, খরচ, আয়, বাজেট, সঞ্চয়, ঋণ/পাওনা ব্যবস্থাপনা
- দ্রুত খরচ যোগ (কয়েক সেকেন্ডে)
- ব্যক্তি ও ক্যাটাগরি অনুযায়ী রিপোর্ট এবং চার্ট (Chart.js)
- JSON ব্যাকআপ/রিস্টোর, CSV এক্সপোর্ট, PDF রিপোর্ট (jsPDF + html2canvas)
- ডার্ক/লাইট/সিস্টেম থিম, বাংলা সংখ্যা পদ্ধতি
- ঐচ্ছিক পিন লক (SHA-256 হ্যাশ, plaintext সংরক্ষণ করা হয় না)
- সম্পূর্ণ PWA সাপোর্ট (`manifest.json` + `service-worker.js`) — ব্রাউজারেও অফলাইনে চলে
- প্রথম লঞ্চ অনবোর্ডিং উইজার্ড, ডেমো ডেটা জেনারেটর

---

## 📁 ফাইল স্ট্রাকচার

```
family-khoroj-manager/
├── package.json
├── capacitor.config.json
├── README.md
├── www/
│   ├── index.html
│   ├── manifest.json
│   ├── service-worker.js
│   ├── css/
│   │   ├── style.css
│   │   └── responsive.css
│   ├── js/
│   │   ├── utils.js       # ফরম্যাটিং, টোস্ট, কনফার্ম ডায়ালগ
│   │   ├── db.js          # IndexedDB ডেটা লেয়ার
│   │   ├── family.js      # পরিবারের সদস্য
│   │   ├── expenses.js    # খরচ ও ক্যাটাগরি
│   │   ├── income.js      # আয়
│   │   ├── budget.js      # বাজেট
│   │   ├── savings.js     # সঞ্চয় লক্ষ্য
│   │   ├── debts.js       # ঋণ/পাওনা
│   │   ├── reports.js     # চার্ট ও রিপোর্ট
│   │   ├── backup.js      # ব্যাকআপ/রিস্টোর/CSV
│   │   ├── pdf.js         # PDF রিপোর্ট
│   │   ├── settings.js    # সেটিংস, থিম, পিন লক
│   │   └── app.js         # রাউটার, ড্যাশবোর্ড, মডাল ফর্ম
│   └── assets/icons/      # অ্যাপ আইকন (প্লেসহোল্ডার — প্রতিস্থাপন করুন)
└── android/                # `npx cap add android` চালানোর পর তৈরি হবে
```

---

## 🔧 প্রয়োজনীয় সফটওয়্যার

- Node.js ≥ 18 এবং npm
- Android Studio (Android SDK, platform-tools সহ) — APK বিল্ড করতে
- JDK 17 (Android Studio-এর সাথে বান্ডিল থাকতে পারে)

---

## 1️⃣ ইনস্টলেশন

```bash
cd family-khoroj-manager
npm install
```

## 2️⃣ ব্রাউজারে ডেভেলপমেন্ট (ঐচ্ছিক, দ্রুত টেস্টের জন্য)

```bash
npm start
# http://localhost:8080 এ ব্রাউজারে খুলুন
```
প্রথমবার Chart.js/jsPDF/html2canvas লোড হতে ইন্টারনেট লাগবে (CDN থেকে); এরপর সার্ভিস ওয়ার্কার সেগুলো ক্যাশ করে রাখবে এবং অ্যাপ পুরোপুরি অফলাইনে চলবে।

## 3️⃣ Capacitor সেটআপ

```bash
npm install @capacitor/core @capacitor/cli
npm install @capacitor/android

npx cap init "Family Khoroj Manager" "com.family.khorojmanager" --web-dir www
# (capacitor.config.json ইতিমধ্যে দেওয়া আছে — init থেকে overwrite করতে বললে হ্যাঁ বলুন অথবা init স্কিপ করুন)

npx cap add android
npx cap sync
```

## 4️⃣ Android Studio-তে খুলুন

```bash
npx cap open android
```

## 5️⃣ Debug APK বিল্ড করুন

```bash
cd android
./gradlew assembleDebug
```
আউটপুট: `android/app/build/outputs/apk/debug/app-debug.apk`

এই APK সরাসরি ফোনে ইনস্টল করে টেস্ট করা যাবে (`adb install app-debug.apk`)।

## 6️⃣ Release APK তৈরি করুন

1. একটি সাইনিং কী তৈরি করুন (একবারই):
   ```bash
   keytool -genkey -v -keystore family-khoroj-release.keystore -alias khoroj -keyalg RSA -keysize 2048 -validity 10000
   ```
2. `android/app/build.gradle`-এ `signingConfigs` ও `buildTypes.release` যোগ করুন, অথবা Android Studio: **Build → Generate Signed Bundle / APK** ব্যবহার করুন এবং উপরের keystore নির্বাচন করুন।
3. রিলিজ বিল্ড চালান:
   ```bash
   ./gradlew assembleRelease
   ```
   আউটপুট: `android/app/build/outputs/apk/release/app-release.apk`

> Play Store-এ প্রকাশ করতে চাইলে `.aab` (Android App Bundle) ব্যবহার করুন: `./gradlew bundleRelease`

---

## 🎨 অ্যাপের নাম/আইকন পরিবর্তন

- **নাম:** `capacitor.config.json`-এ `appName` পরিবর্তন করে `npx cap sync` চালান। Android-এ নাম পরিবর্তনের জন্য `android/app/src/main/res/values/strings.xml`-এর `app_name` ও পরিবর্তন করুন।
- **আইকন:** `www/assets/icons/icon-192.png`, `icon-512.png`, `icon-maskable-512.png` প্রতিস্থাপন করুন (বর্তমানগুলো প্লেসহোল্ডার)। Android নেটিভ আইকনের জন্য Android Studio-তে রাইট-ক্লিক `res` ফোল্ডার → **New → Image Asset** ব্যবহার করে সব ডেনসিটির আইকন জেনারেট করুন, অথবা [Capacitor Assets](https://github.com/ionic-team/capacitor-assets) টুল ব্যবহার করুন:
  ```bash
  npm install @capacitor/assets --save-dev
  npx capacitor-assets generate --android
  ```

---

## 🔌 নতুন Capacitor প্লাগইন যোগ করা

```bash
npm install @capacitor/<plugin-name>
npx cap sync
```
উদাহরণ (রিমাইন্ডার নোটিফিকেশনের জন্য):
```bash
npm install @capacitor/local-notifications
npx cap sync
```
তারপর `js/app.js`-এ `Capacitor.isNativePlatform()` চেক করে প্লাগইন কল যোগ করুন যাতে ওয়েব/PWA সংস্করণে ভেঙে না যায়।

---

## 🛠️ সাধারণ সমস্যা সমাধান (Troubleshooting)

| সমস্যা | সমাধান |
|---|---|
| `npx cap sync` এ error | নিশ্চিত করুন `www/` ফোল্ডার আছে এবং `capacitor.config.json`-এ `webDir: "www"` ঠিক আছে |
| Gradle বিল্ড ফেইল | Android Studio খুলে **File → Sync Project with Gradle Files** চালান; JDK 17 নিশ্চিত করুন |
| চার্ট/PDF কাজ করছে না অফলাইনে | প্রথমবার অ্যাপ চালু করার সময় ইন্টারনেট সংযোগ প্রয়োজন যাতে CDN লাইব্রেরি ক্যাশ হয়; এরপর অফলাইনে কাজ করবে। অথবা `Chart.js`/`jsPDF`/`html2canvas` ফাইলগুলো ডাউনলোড করে `www/js/vendor/`-এ রেখে `index.html`-এ লোকাল পাথ দিন |
| বাংলা ফন্ট ঠিকমতো দেখাচ্ছে না | ইন্টারনেট ছাড়া প্রথমবার Google Fonts (Noto Sans Bengali) লোড হবে না; স্থায়ী সমাধানের জন্য ফন্ট ফাইল ডাউনলোড করে `www/assets/fonts/`-এ রেখে `@font-face` দিয়ে লোকালি লোড করুন |
| ডেটা হারিয়ে গেছে | IndexedDB ডিভাইস-নির্দিষ্ট; অ্যাপ আনইনস্টল করলে ডেটা মুছে যায় — নিয়মিত সেটিংস থেকে "ব্যাকআপ ডাউনলোড করুন" ব্যবহার করুন |
| APK ইনস্টল হচ্ছে না ("App not installed") | পুরনো ভার্সন আনইনস্টল করুন, অথবা ফোনে "Unknown sources" পারমিশন চালু করুন |

---

## 📴 অফলাইন-ফার্স্ট আর্কিটেকচার নোট

- সব মূল ডেটা **IndexedDB**-তে (localStorage নয়) সংরক্ষিত — বড় ডেটাসেট ও স্ট্রাকচার্ড কোয়েরির জন্য উপযুক্ত।
- Chart.js, jsPDF, html2canvas শুধুমাত্র CDN থেকে লোড হয় (অ্যাপ সাইজ ছোট রাখতে); Service Worker প্রথম লোডের পর সেগুলো ক্যাশ করে রাখে।
- ভবিষ্যতে cloud sync/family sharing যোগ করতে চাইলে `db.js`-এর `exportAll()`/`importAll()` ফাংশনগুলো ইতিমধ্যে একটি ক্লিন সিঙ্ক-রেডি ডেটা স্ট্রাকচার প্রদান করে।

---

## 🔒 নিরাপত্তা নোট

- পিন কখনো plaintext সংরক্ষিত হয় না — Web Crypto API (SHA-256) দিয়ে হ্যাশ করা হয়।
- ব্যাকআপ ইমপোর্টের সময় ফাইল স্ট্রাকচার যাচাই করা হয়; কোনো কোড এক্সিকিউট করা হয় না (`JSON.parse` ব্যবহৃত, `eval()` নয়)।
- ধ্বংসাত্মক কাজ (ডেটা মুছে ফেলা, ব্যাকআপ রিস্টোর) সবসময় কনফার্মেশন ডায়ালগ দেখায়।

---

## লাইসেন্স

MIT — স্বাধীনভাবে পরিবর্তন ও ব্যবহার করতে পারবেন।
