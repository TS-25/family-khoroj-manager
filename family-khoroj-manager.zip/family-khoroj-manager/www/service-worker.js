/* ==========================================================================
   service-worker.js — Offline-first caching for the PWA build.
   IndexedDB data is untouched by this worker; it only caches static assets
   so the app shell loads instantly without a network connection.
   ========================================================================== */

const CACHE_NAME = 'family-khoroj-cache-v1';
const CORE_ASSETS = [
  './',
  './index.html',
  './manifest.json',
  './css/style.css',
  './css/responsive.css',
  './js/utils.js',
  './js/db.js',
  './js/family.js',
  './js/expenses.js',
  './js/income.js',
  './js/budget.js',
  './js/savings.js',
  './js/debts.js',
  './js/reports.js',
  './js/backup.js',
  './js/pdf.js',
  './js/settings.js',
  './js/app.js'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(CORE_ASSETS)).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;

  // Network-first for CDN-hosted libraries so users get updates when online,
  // but fall back to cache when offline.
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) {
    event.respondWith(
      fetch(req).then((res) => {
        const resClone = res.clone();
        caches.open(CACHE_NAME).then((cache) => cache.put(req, resClone));
        return res;
      }).catch(() => caches.match(req))
    );
    return;
  }

  // Cache-first for the app shell (fast + fully offline).
  event.respondWith(
    caches.match(req).then((cached) => {
      if (cached) return cached;
      return fetch(req).then((res) => {
        const resClone = res.clone();
        caches.open(CACHE_NAME).then((cache) => cache.put(req, resClone));
        return res;
      }).catch(() => caches.match('./index.html'));
    })
  );
});
