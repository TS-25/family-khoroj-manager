/* ==========================================================================
   family.js — Family member management
   ========================================================================== */
'use strict';

const Family = (() => {

  const DEFAULT_MEMBERS = [
    { name: 'বাবা', icon: '👨', color: '#2E7D5B' },
    { name: 'মা', icon: '👩', color: '#C77D2A' }
  ];

  async function seedDefaultsIfEmpty() {
    const existing = await DB.getAll('familyMembers');
    if (existing.length === 0) {
      for (const m of DEFAULT_MEMBERS) {
        await add(m);
      }
    }
  }

  async function getAll() {
    const list = await DB.getAll('familyMembers');
    return list.sort((a, b) => (a.order || 0) - (b.order || 0) || a.createdAt.localeCompare(b.createdAt));
  }

  async function getById(id) {
    return DB.get('familyMembers', id);
  }

  async function add({ name, icon = '🧑', color = '#2E7D5B', monthlyBudget = 0 }) {
    name = (name || '').trim();
    if (!name) throw new Error('নাম আবশ্যক।');
    const now = Utils.nowISO();
    const record = {
      id: Utils.uuid(),
      name, icon, color,
      monthlyBudget: Number(monthlyBudget) || 0,
      createdAt: now, updatedAt: now
    };
    await DB.put('familyMembers', record);
    return record;
  }

  async function update(id, patch) {
    const existing = await DB.get('familyMembers', id);
    if (!existing) throw new Error('সদস্য পাওয়া যায়নি।');
    const updated = { ...existing, ...patch, updatedAt: Utils.nowISO() };
    await DB.put('familyMembers', updated);
    return updated;
  }

  async function remove(id) {
    await DB.remove('familyMembers', id);
  }

  return { DEFAULT_MEMBERS, seedDefaultsIfEmpty, getAll, getById, add, update, remove };
})();
