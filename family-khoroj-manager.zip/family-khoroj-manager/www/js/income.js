/* ==========================================================================
   income.js — Income CRUD and list page
   ========================================================================== */
'use strict';

const Income = (() => {

  const SOURCES = ['বেতন', 'ব্যবসা', 'ফ্রিল্যান্সিং', 'উপহার', 'অন্যান্য'];

  async function getAll() {
    const list = await DB.getAll('income');
    return list.sort((a, b) => new Date(b.date) - new Date(a.date));
  }

  async function getById(id) { return DB.get('income', id); }

  async function add(data) {
    const now = Utils.nowISO();
    const record = {
      id: Utils.uuid(),
      amount: Number(data.amount),
      personId: data.personId || '',
      personName: data.personName || '',
      source: data.source || 'অন্যান্য',
      date: data.date || Utils.todayISO(),
      note: data.note || '',
      createdAt: now, updatedAt: now
    };
    await DB.put('income', record);
    return record;
  }

  async function update(id, patch) {
    const existing = await DB.get('income', id);
    if (!existing) throw new Error('আয় পাওয়া যায়নি।');
    const updated = { ...existing, ...patch, updatedAt: Utils.nowISO() };
    await DB.put('income', updated);
    return updated;
  }

  async function remove(id) { await DB.remove('income', id); }

  async function getByMonth(monthKey) {
    const all = await getAll();
    return all.filter(i => Utils.monthKey(i.date) === monthKey);
  }

  function sum(list) { return list.reduce((s, i) => s + Number(i.amount || 0), 0); }

  async function renderPage() {
    const container = document.getElementById('page-content');
    const list = await getAll();
    const monthList = await getByMonth(Utils.currentMonthKey());
    const monthTotal = sum(monthList);

    container.innerHTML = `
      <div class="balance-hero" style="background:linear-gradient(135deg,var(--success),var(--primary-dark));">
        <div class="label">এই মাসের মোট আয়</div>
        <div class="amount">${Utils.fmtMoney(monthTotal)}</div>
      </div>
      <div class="section-title">সকল আয়ের তালিকা</div>
      <div id="income-list"></div>
    `;

    const listEl = document.getElementById('income-list');
    if (list.length === 0) {
      listEl.innerHTML = `<div class="empty-state"><div class="icon">💵</div><div class="title">কোনো আয় যোগ করা হয়নি</div><div class="desc">উপরের + বাটন থেকে "আয়" ট্যাব বেছে যোগ করুন</div></div>`;
    } else {
      const grouped = {};
      list.forEach(i => { if (!grouped[i.date]) grouped[i.date] = []; grouped[i.date].push(i); });
      listEl.innerHTML = Object.keys(grouped).sort((a, b) => b.localeCompare(a)).map(date => `
        <div class="date-group-header"><span>${Utils.relativeDayLabel(date)}</span><span>${Utils.fmtMoney(sum(grouped[date]))}</span></div>
        <div class="card" style="padding:4px 12px;">
          ${grouped[date].map(i => `
            <div class="list-row" data-id="${i.id}" role="button" tabindex="0">
              <div class="avatar">💵</div>
              <div class="info">
                <div class="title">${Utils.escapeHtml(i.source)}${i.personName ? ' · ' + Utils.escapeHtml(i.personName) : ''}</div>
                <div class="sub">${i.note ? Utils.escapeHtml(i.note) : Utils.fmtDateLong(i.date)}</div>
              </div>
              <div class="amount positive">+${Utils.fmtMoney(i.amount)}</div>
            </div>
          `).join('')}
        </div>
      `).join('');

      listEl.querySelectorAll('.list-row').forEach(row => {
        row.addEventListener('click', async () => {
          const ok = await Utils.confirmDialog({ title: 'আয় মুছবেন?', message: 'এই আয়ের তথ্য স্থায়ীভাবে মুছে যাবে।', okText: 'মুছে ফেলুন' });
          if (ok) { await remove(row.dataset.id); Utils.toast('মুছে ফেলা হয়েছে', 'success'); renderPage(); App.refreshDashboardBadge(); }
        });
      });
    }
  }

  return { SOURCES, getAll, getById, add, update, remove, getByMonth, sum, renderPage };
})();
