/* ==========================================================================
   budget.js — Monthly budget tracking per category
   ========================================================================== */
'use strict';

const Budget = (() => {

  async function getAll() { return DB.getAll('budgets'); }

  async function getByCategory(category) {
    const all = await getAll();
    return all.find(b => b.category === category) || null;
  }

  async function setCategoryBudget(category, limit) {
    const existing = await getByCategory(category);
    const record = existing
      ? { ...existing, limit: Number(limit), updatedAt: Utils.nowISO() }
      : { id: Utils.uuid(), category, limit: Number(limit), createdAt: Utils.nowISO(), updatedAt: Utils.nowISO() };
    await DB.put('budgets', record);
    return record;
  }

  async function removeCategoryBudget(id) { await DB.remove('budgets', id); }

  async function getOverallBudget() { return Number(await Settings.get('overallBudget', 0)) || 0; }
  async function setOverallBudget(v) { await Settings.set('overallBudget', Number(v) || 0); }

  function statusClass(percent) {
    if (percent >= 100) return 'danger';
    if (percent >= 80) return 'warn';
    return '';
  }

  async function renderPage() {
    const container = document.getElementById('page-content');
    const overall = await getOverallBudget();
    const monthExpenses = await Expenses.getByMonth(Utils.currentMonthKey());
    const monthTotal = Expenses.sum(monthExpenses);
    const budgets = await getAll();
    const categories = await Expenses.getAllCategories();

    const overallPercent = overall > 0 ? Math.min(100, Math.round((monthTotal / overall) * 100)) : 0;
    const overallCls = statusClass(overall > 0 ? (monthTotal / overall) * 100 : 0);

    let warningHtml = '';
    if (overall > 0) {
      if (monthTotal >= overall) warningHtml = `<div class="badge" style="background:var(--danger-light);color:var(--danger);margin-top:8px;">আপনার নির্ধারিত বাজেট অতিক্রম করেছে।</div>`;
      else if (monthTotal / overall >= 0.8) warningHtml = `<div class="badge" style="background:var(--warning-light);color:var(--warning);margin-top:8px;">আপনার বাজেটের ৮০% খরচ হয়ে গেছে।</div>`;
    }

    container.innerHTML = `
      <div class="card">
        <div class="section-title">মাসিক সামগ্রিক বাজেট</div>
        <div class="field" style="margin-bottom:8px;">
          <div class="amount-input-wrap">
            <span class="currency-sign">৳</span>
            <input type="number" id="overall-budget-input" value="${overall || ''}" placeholder="যেমন: ২৫০০০" inputmode="decimal">
          </div>
        </div>
        <button class="btn btn-primary" id="save-overall-budget">সংরক্ষণ করুন</button>
        ${overall > 0 ? `
        <div style="margin-top:14px;">
          <div class="progress-track"><div class="progress-fill ${overallCls}" style="width:${overallPercent}%"></div></div>
          <div style="display:flex;justify-content:space-between;font-size:12.5px;color:var(--muted);margin-top:6px;">
            <span>খরচ: ${Utils.fmtMoney(monthTotal)}</span><span>বাজেট: ${Utils.fmtMoney(overall)}</span>
          </div>
          ${warningHtml}
        </div>` : ''}
      </div>

      <div class="section-title">ক্যাটাগরি অনুযায়ী বাজেট</div>
      <div id="cat-budget-list"></div>
    `;

    document.getElementById('save-overall-budget').addEventListener('click', async () => {
      const v = document.getElementById('overall-budget-input').value;
      await setOverallBudget(v);
      Utils.toast('বাজেট সংরক্ষণ করা হয়েছে', 'success');
      renderPage();
    });

    const listEl = document.getElementById('cat-budget-list');
    const catSpend = {};
    monthExpenses.forEach(e => { catSpend[e.category] = (catSpend[e.category] || 0) + Number(e.amount); });

    listEl.innerHTML = categories.map(c => {
      const b = budgets.find(x => x.category === c.name);
      const limit = b ? b.limit : 0;
      const spent = catSpend[c.name] || 0;
      const remaining = limit - spent;
      const pct = limit > 0 ? Math.min(100, Math.round((spent / limit) * 100)) : 0;
      const cls = statusClass(limit > 0 ? (spent / limit) * 100 : 0);
      return `
        <div class="card" data-category="${Utils.escapeHtml(c.name)}">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
            <div style="font-weight:700;">${c.icon || '🏷️'} ${Utils.escapeHtml(c.name)}</div>
            <button class="btn btn-sm btn-outline edit-cat-budget-btn">${limit > 0 ? 'সম্পাদনা' : 'বাজেট সেট করুন'}</button>
          </div>
          ${limit > 0 ? `
          <div class="progress-track"><div class="progress-fill ${cls}" style="width:${pct}%"></div></div>
          <div style="display:flex;justify-content:space-between;font-size:12px;color:var(--muted);margin-top:6px;">
            <span>খরচ: ${Utils.fmtMoney(spent)}</span>
            <span>বাকি: ${Utils.fmtMoney(Math.max(0, remaining))}</span>
          </div>` : `<div class="hint" style="color:var(--muted);font-size:12.5px;">এখনো কোনো বাজেট নির্ধারণ করা হয়নি।</div>`}
        </div>
      `;
    }).join('');

    listEl.querySelectorAll('.edit-cat-budget-btn').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        const card = e.target.closest('[data-category]');
        const category = card.dataset.category;
        const existing = budgets.find(x => x.category === category);
        const val = prompt(`"${category}" এর জন্য মাসিক বাজেট (৳) লিখুন:`, existing ? existing.limit : '');
        if (val === null) return;
        const v = Utils.validateAmount(val);
        if (!v.valid) { Utils.toast(v.msg, 'error'); return; }
        await setCategoryBudget(category, v.value);
        Utils.toast('বাজেট সংরক্ষণ করা হয়েছে', 'success');
        renderPage();
      });
    });
  }

  return { getAll, getByCategory, setCategoryBudget, removeCategoryBudget, getOverallBudget, setOverallBudget, renderPage };
})();
