/* ==========================================================================
   app.js — Router, dashboard, add expense/income flow, onboarding, PIN lock
   ========================================================================== */
'use strict';

const App = (() => {

  const PAGE_TITLES = {
    dashboard: 'ড্যাশবোর্ড', expenses: 'প্রতিদিনের খরচ', reports: 'রিপোর্ট',
    family: 'পরিবারের সদস্য', settings: 'সেটিংস', income: 'আয়',
    budget: 'বাজেট', savings: 'সঞ্চয়', debts: 'ঋণ ও পাওনা'
  };

  let currentRoute = 'dashboard';
  let searchMode = false;

  // ---------------- Boot sequence ----------------
  async function init() {
    await DB.open();
    await Settings.loadAll();
    Settings.initTheme();
    await Family.seedDefaultsIfEmpty();
    await Expenses.seedDefaultCategoriesIfEmpty();

    const firstLaunchDone = Settings.get('onboardingDone', false);

    document.getElementById('boot-loader').remove();

    if (Settings.isPinEnabled()) {
      showPinLockScreen(() => afterUnlock(firstLaunchDone));
    } else {
      afterUnlock(firstLaunchDone);
    }

    registerServiceWorker();
  }

  function afterUnlock(firstLaunchDone) {
    document.getElementById('app').classList.remove('hidden');
    if (!firstLaunchDone) {
      runOnboarding();
    } else {
      bindNav();
      navigate('dashboard');
    }
    showDeveloperPopup();
  }

  // ---------------- Developer credit popup (shown on every app open) ----------------
  function showDeveloperPopup() {
    const modalRoot = document.getElementById('modal-root');
    const wrapper = document.createElement('div');
    wrapper.className = 'modal-overlay center';
    wrapper.id = 'developer-credit-modal';
    wrapper.innerHTML = `
      <div class="modal-sheet" style="text-align:center;max-width:320px;">
        <div style="font-size:30px;margin-bottom:8px;">👨‍💻</div>
        <h3 style="margin:0 0 6px;font-size:16px;">Developed by Tanvir Sami</h3>
        <button class="btn btn-primary" id="close-developer-credit" style="margin-top:14px;">ঠিক আছে</button>
      </div>`;
    modalRoot.appendChild(wrapper);

    function close() { wrapper.remove(); }
    document.getElementById('close-developer-credit').addEventListener('click', close);
    wrapper.addEventListener('click', (e) => { if (e.target.id === 'developer-credit-modal') close(); });
  }

  function registerServiceWorker() {
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('service-worker.js').catch(() => {});
    }
  }

  // ---------------- Navigation ----------------
  function bindNav() {
    document.querySelectorAll('.nav-item').forEach(btn => {
      btn.addEventListener('click', () => navigate(btn.dataset.route));
    });
    document.getElementById('fab-add').addEventListener('click', () => openAddEntryModal());
    document.getElementById('back-btn').addEventListener('click', () => navigate('dashboard'));
    document.getElementById('search-toggle-btn').addEventListener('click', toggleSearch);
    document.getElementById('search-input').addEventListener('input', Utils.debounce(runSearch, 300));
  }

  function toggleSearch() {
    searchMode = !searchMode;
    const bar = document.getElementById('search-bar');
    bar.classList.toggle('hidden', !searchMode);
    if (searchMode) {
      document.getElementById('search-input').value = '';
      document.getElementById('search-input').focus();
      navigate('searchResults', { skipNavHighlight: true });
    } else {
      navigate(currentRoute === 'searchResults' ? 'dashboard' : currentRoute);
    }
  }

  async function runSearch() {
    const q = document.getElementById('search-input').value.trim();
    const container = document.getElementById('page-content');
    if (!q) { container.innerHTML = `<div class="empty-state"><div class="icon">🔎</div><div class="desc">খুঁজতে টাইপ করুন...</div></div>`; return; }
    const results = await Expenses.search(q);
    document.getElementById('page-title').textContent = `"${q}" এর ফলাফল`;
    if (results.length === 0) {
      container.innerHTML = `<div class="empty-state"><div class="icon">🔎</div><div class="title">কোনো ফলাফল পাওয়া যায়নি</div></div>`;
      return;
    }
    container.innerHTML = `<div class="card" style="padding:4px 12px;">${results.map(e => Expenses.expenseRowHtml(e)).join('')}</div>`;
    container.querySelectorAll('.list-row').forEach(row => row.addEventListener('click', () => openExpenseDetail(row.dataset.id)));
  }

  async function navigate(route, opts = {}) {
    currentRoute = route;
    document.getElementById('page-title').textContent = PAGE_TITLES[route] || '';
    document.getElementById('back-btn').classList.toggle('hidden', route === 'dashboard' || route === 'searchResults' ? route !== 'searchResults' : false);
    if (route !== 'searchResults') {
      document.getElementById('back-btn').classList.toggle('hidden', ['dashboard', 'expenses', 'reports', 'family', 'settings'].includes(route));
    }

    if (!opts.skipNavHighlight) {
      document.querySelectorAll('.nav-item').forEach(btn => btn.classList.toggle('active', btn.dataset.route === route));
    }

    Reports.destroyCharts();
    window.scrollTo(0, 0);

    switch (route) {
      case 'dashboard': await renderDashboard(); break;
      case 'expenses': await Expenses.renderPage(); break;
      case 'reports': await Reports.renderPage(); break;
      case 'family': await renderFamilyPage(); break;
      case 'settings': await Settings.renderPage(); break;
      case 'income': await Income.renderPage(); break;
      case 'budget': await Budget.renderPage(); break;
      case 'savings': await Savings.renderPage(); break;
      case 'debts': await Debts.renderPage(); break;
      case 'memberDetail': await renderMemberDetailPage(opts.memberId); break;
      default: await renderDashboard();
    }
  }

  // ---------------- Dashboard ----------------
  async function renderDashboard() {
    const container = document.getElementById('page-content');
    container.innerHTML = `<div class="skeleton" style="height:150px;margin-bottom:14px;border-radius:22px;"></div>
      <div class="skeleton" style="height:70px;margin-bottom:14px;"></div>`;

    const monthKey = Utils.currentMonthKey();
    const monthExpenses = await Expenses.getByMonth(monthKey);
    const monthIncome = await Income.getByMonth(monthKey);
    const allExpenses = await Expenses.getAll();
    const allIncome = await Income.getAll();

    const totalExpense = Expenses.sum(monthExpenses);
    const totalIncome = Income.sum(monthIncome);
    const monthSavings = totalIncome - totalExpense;
    const overallBalance = Income.sum(allIncome) - Expenses.sum(allExpenses);

    const todayExpenses = await Expenses.getToday();
    const todayTotal = Expenses.sum(todayExpenses);

    container.innerHTML = `
      <div class="balance-hero">
        <div class="label">মোট ব্যালেন্স</div>
        <div class="amount">${Utils.fmtMoney(overallBalance)}</div>
        <div class="balance-grid">
          <div class="b-item"><div class="b-label">এই মাসের আয়</div><div class="b-value">${Utils.fmtMoney(totalIncome)}</div></div>
          <div class="b-item"><div class="b-label">এই মাসের খরচ</div><div class="b-value">${Utils.fmtMoney(totalExpense)}</div></div>
          <div class="b-item"><div class="b-label">সঞ্চয়</div><div class="b-value">${Utils.fmtMoney(monthSavings)}</div></div>
        </div>
      </div>

      <div class="stat-grid">
        <button class="stat-card" style="text-align:right;border:1px solid var(--border);" id="quick-income-card">
          <div class="s-label">➕ আয় যোগ করুন</div>
        </button>
        <button class="stat-card" style="text-align:right;border:1px solid var(--border);" id="quick-budget-card">
          <div class="s-label">🎯 বাজেট দেখুন</div>
        </button>
      </div>

      <div class="section-title">আজকের খরচ <span style="color:var(--danger);">${Utils.fmtMoney(todayTotal)}</span></div>
      <div id="today-expenses-list"></div>

      <div class="section-title" style="margin-top:16px;">দ্রুত অ্যাক্সেস</div>
      <div class="chip-row">
        <button class="chip" id="go-savings">🎯 সঞ্চয়</button>
        <button class="chip" id="go-debts">🤝 ঋণ ও পাওনা</button>
        <button class="chip" id="go-income">💵 আয়ের তালিকা</button>
      </div>
    `;

    const listEl = document.getElementById('today-expenses-list');
    if (todayExpenses.length === 0) {
      listEl.innerHTML = `<div class="empty-state"><div class="icon">🧾</div><div class="title">আজ কোনো খরচ যোগ করা হয়নি</div><div class="desc">নিচের + বাটনে চেপে খরচ যোগ করুন</div></div>`;
    } else {
      listEl.innerHTML = `<div class="card" style="padding:4px 12px;">${todayExpenses.slice(0, 8).map(e => Expenses.expenseRowHtml(e)).join('')}</div>`;
      listEl.querySelectorAll('.list-row').forEach(row => row.addEventListener('click', () => openExpenseDetail(row.dataset.id)));
    }

    document.getElementById('quick-income-card').addEventListener('click', () => navigate('income'));
    document.getElementById('quick-budget-card').addEventListener('click', () => navigate('budget'));
    document.getElementById('go-savings').addEventListener('click', () => navigate('savings'));
    document.getElementById('go-debts').addEventListener('click', () => navigate('debts'));
    document.getElementById('go-income').addEventListener('click', () => navigate('income'));
  }

  function refreshDashboardBadge() {
    if (currentRoute === 'dashboard') renderDashboard();
  }

  // ---------------- Family page ----------------
  async function renderFamilyPage() {
    const container = document.getElementById('page-content');
    const members = await Family.getAll();
    const monthKey = Utils.currentMonthKey();
    const monthExpenses = await Expenses.getByMonth(monthKey);

    const spendByPerson = {};
    monthExpenses.forEach(e => { spendByPerson[e.personId] = (spendByPerson[e.personId] || 0) + Number(e.amount); });

    container.innerHTML = `
      <div class="section-title">পরিবারের সদস্য <button class="btn btn-sm btn-primary" id="add-member-btn">+ সদস্য যোগ করুন</button></div>
      <div id="member-list"></div>
    `;

    const listEl = document.getElementById('member-list');
    if (members.length === 0) {
      listEl.innerHTML = `<div class="empty-state"><div class="icon">👨‍👩‍👧</div><div class="title">কোনো সদস্য নেই</div></div>`;
    } else {
      listEl.innerHTML = members.map(m => `
        <div class="card" data-id="${m.id}" role="button" style="display:flex;align-items:center;gap:14px;">
          <div class="avatar" style="background:${m.color}22;color:${m.color};font-size:24px;">${m.icon}</div>
          <div style="flex:1;">
            <div style="font-weight:700;">${Utils.escapeHtml(m.name)}</div>
            <div style="color:var(--muted);font-size:13px;">এই মাসে খরচ: ${Utils.fmtMoney(spendByPerson[m.id] || 0)}</div>
          </div>
          <span style="color:var(--muted);">›</span>
        </div>
      `).join('');
      listEl.querySelectorAll('[data-id]').forEach(card => {
        card.addEventListener('click', () => navigate('memberDetail', { memberId: card.dataset.id }));
      });
    }

    document.getElementById('add-member-btn').addEventListener('click', () => openMemberForm());
  }

  function openMemberForm(member = null) {
    const modalRoot = document.getElementById('modal-root');
    modalRoot.innerHTML = `
      <div class="modal-overlay" id="member-modal">
        <div class="modal-sheet">
          <div class="modal-drag-handle"></div>
          <div class="modal-header"><h2>${member ? 'সদস্য সম্পাদনা' : 'নতুন সদস্য যোগ করুন'}</h2><button class="icon-btn" id="close-member-modal">✕</button></div>
          <div class="field"><label>নাম</label><input id="member-name" type="text" placeholder="যেমন: ভাই" value="${member ? Utils.escapeHtml(member.name) : ''}"></div>
          <div class="field"><label>আইকন</label>
            <div class="chip-row">${Utils.PERSON_ICONS.map(icon => `<button type="button" class="chip icon-choice ${member && member.icon === icon ? 'active' : ''}" data-icon="${icon}" style="font-size:18px;">${icon}</button>`).join('')}</div>
          </div>
          <div class="field"><label>রং</label>
            <div class="chip-row">${Utils.MEMBER_COLORS.map(c => `<button type="button" class="color-choice ${member && member.color === c ? 'active' : ''}" data-color="${c}" style="width:32px;height:32px;border-radius:50%;background:${c};border:3px solid ${member && member.color === c ? 'var(--text)' : 'transparent'};"></button>`).join('')}</div>
          </div>
          <div class="field"><label>মাসিক বাজেট (ঐচ্ছিক)</label>
            <div class="amount-input-wrap"><span class="currency-sign">৳</span><input id="member-budget" type="number" inputmode="decimal" value="${member && member.monthlyBudget ? member.monthlyBudget : ''}"></div>
          </div>
          <button class="btn btn-primary" id="save-member-btn">সংরক্ষণ করুন</button>
          ${member ? `<button class="btn btn-danger" id="delete-member-btn" style="margin-top:10px;">সদস্য মুছে ফেলুন</button>` : ''}
        </div>
      </div>`;

    let selectedIcon = member ? member.icon : Utils.PERSON_ICONS[0];
    let selectedColor = member ? member.color : Utils.MEMBER_COLORS[0];

    document.getElementById('close-member-modal').addEventListener('click', () => modalRoot.innerHTML = '');
    document.getElementById('member-modal').addEventListener('click', (e) => { if (e.target.id === 'member-modal') modalRoot.innerHTML = ''; });

    modalRoot.querySelectorAll('.icon-choice').forEach(btn => btn.addEventListener('click', () => {
      selectedIcon = btn.dataset.icon;
      modalRoot.querySelectorAll('.icon-choice').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
    }));
    modalRoot.querySelectorAll('.color-choice').forEach(btn => btn.addEventListener('click', () => {
      selectedColor = btn.dataset.color;
      modalRoot.querySelectorAll('.color-choice').forEach(b => b.style.borderColor = 'transparent');
      btn.style.borderColor = 'var(--text)';
    }));

    document.getElementById('save-member-btn').addEventListener('click', async () => {
      const name = document.getElementById('member-name').value.trim();
      const budget = document.getElementById('member-budget').value;
      if (!name) { Utils.toast('নাম লিখুন।', 'error'); return; }
      try {
        if (member) await Family.update(member.id, { name, icon: selectedIcon, color: selectedColor, monthlyBudget: Number(budget) || 0 });
        else await Family.add({ name, icon: selectedIcon, color: selectedColor, monthlyBudget: Number(budget) || 0 });
        modalRoot.innerHTML = '';
        Utils.toast('সংরক্ষণ করা হয়েছে', 'success');
        navigate('family');
      } catch (err) { Utils.toast(err.message || 'সংরক্ষণ করা যায়নি।', 'error'); }
    });

    const deleteBtn = document.getElementById('delete-member-btn');
    if (deleteBtn) deleteBtn.addEventListener('click', async () => {
      const ok = await Utils.confirmDialog({ title: 'সদস্য মুছবেন?', message: 'এই সদস্যের প্রোফাইল মুছে যাবে (তাদের খরচের ইতিহাস থেকে যাবে)।', okText: 'মুছে ফেলুন' });
      if (ok) { await Family.remove(member.id); modalRoot.innerHTML = ''; Utils.toast('মুছে ফেলা হয়েছে', 'success'); navigate('family'); }
    });
  }

  async function renderMemberDetailPage(memberId) {
    const container = document.getElementById('page-content');
    const member = await Family.getById(memberId);
    if (!member) { navigate('family'); return; }
    document.getElementById('page-title').textContent = member.name;

    const monthKey = Utils.currentMonthKey();
    const monthExpenses = (await Expenses.getByMonth(monthKey)).filter(e => e.personId === memberId);
    const todayExpenses = (await Expenses.getToday()).filter(e => e.personId === memberId);
    const allExpenses = (await Expenses.getAll()).filter(e => e.personId === memberId);

    const byCategory = {};
    monthExpenses.forEach(e => { byCategory[e.category] = (byCategory[e.category] || 0) + Number(e.amount); });
    const catEntries = Object.entries(byCategory).sort((a, b) => b[1] - a[1]);

    container.innerHTML = `
      <div class="card" style="text-align:center;">
        <div class="avatar" style="width:60px;height:60px;font-size:30px;background:${member.color}22;color:${member.color};margin:0 auto 10px;">${member.icon}</div>
        <div style="font-weight:800;font-size:17px;">${Utils.escapeHtml(member.name)}</div>
        <button class="btn btn-sm btn-outline" id="edit-member-btn" style="margin-top:10px;width:auto;padding:8px 18px;">সম্পাদনা</button>
      </div>

      <div class="stat-grid">
        <div class="stat-card expense"><div class="s-label">আজকের খরচ</div><div class="s-value">${Utils.fmtMoney(Expenses.sum(todayExpenses))}</div></div>
        <div class="stat-card expense"><div class="s-label">এই মাসের খরচ</div><div class="s-value">${Utils.fmtMoney(Expenses.sum(monthExpenses))}</div></div>
      </div>

      <div class="card">
        <div class="section-title">ক্যাটাগরি অনুযায়ী (এই মাস)</div>
        ${catEntries.length === 0 ? `<div class="hint" style="color:var(--muted);">কোনো খরচ নেই</div>` :
          catEntries.map(([cat, amt], i) => `
          <div style="display:flex;justify-content:space-between;padding:8px 0;${i > 0 ? 'border-top:1px solid var(--border);' : ''}">
            <span>${Expenses.categoryIcon(cat) || '🏷️'} ${Utils.escapeHtml(cat)}</span><b>${Utils.fmtMoney(amt)}</b>
          </div>`).join('')}
      </div>

      <div class="section-title">সাম্প্রতিক খরচের ইতিহাস</div>
      <div id="member-history-list"></div>
    `;

    const historyEl = document.getElementById('member-history-list');
    if (allExpenses.length === 0) {
      historyEl.innerHTML = `<div class="empty-state"><div class="icon">🧾</div><div class="desc">কোনো খরচের ইতিহাস নেই</div></div>`;
    } else {
      historyEl.innerHTML = `<div class="card" style="padding:4px 12px;">${allExpenses.slice(0, 30).map(e => Expenses.expenseRowHtml(e)).join('')}</div>`;
      historyEl.querySelectorAll('.list-row').forEach(row => row.addEventListener('click', () => openExpenseDetail(row.dataset.id)));
    }

    document.getElementById('edit-member-btn').addEventListener('click', () => openMemberForm(member));
  }

  // ---------------- Add Entry (Expense / Income) Modal ----------------
  async function openAddEntryModal(entryType = 'expense') {
    const modalRoot = document.getElementById('modal-root');
    const members = await Family.getAll();
    if (members.length === 0) { Utils.toast('প্রথমে একজন পরিবারের সদস্য যোগ করুন।', 'warning'); navigate('family'); return; }
    const categories = await Expenses.getAllCategories();

    modalRoot.innerHTML = `
      <div class="modal-overlay" id="add-entry-modal">
        <div class="modal-sheet">
          <div class="modal-drag-handle"></div>
          <div class="modal-header">
            <h2>${entryType === 'expense' ? 'খরচ যোগ করুন' : 'আয় যোগ করুন'}</h2>
            <button class="icon-btn" id="close-entry-modal">✕</button>
          </div>
          <div class="chip-row" style="margin-bottom:16px;">
            <button class="chip ${entryType === 'expense' ? 'active' : ''}" id="tab-expense" style="flex:1;">💸 খরচ</button>
            <button class="chip ${entryType === 'income' ? 'active' : ''}" id="tab-income" style="flex:1;">💵 আয়</button>
          </div>
          <div id="entry-form-body"></div>
        </div>
      </div>`;

    document.getElementById('close-entry-modal').addEventListener('click', () => modalRoot.innerHTML = '');
    document.getElementById('add-entry-modal').addEventListener('click', (e) => { if (e.target.id === 'add-entry-modal') modalRoot.innerHTML = ''; });
    document.getElementById('tab-expense').addEventListener('click', () => openAddEntryModal('expense'));
    document.getElementById('tab-income').addEventListener('click', () => openAddEntryModal('income'));

    if (entryType === 'expense') renderExpenseForm(members, categories);
    else renderIncomeForm(members);
  }

  function renderExpenseForm(members, categories) {
    const body = document.getElementById('entry-form-body');
    body.innerHTML = `
      <div class="field">
        <label>পরিমাণ</label>
        <div class="amount-input-wrap"><span class="currency-sign">৳</span><input id="exp-amount" type="number" inputmode="decimal" placeholder="0" autofocus></div>
        <div class="error-text" id="exp-amount-error"></div>
      </div>
      <div class="field">
        <label>ব্যক্তি</label>
        <div class="chip-row" id="exp-person-chips">
          ${members.map((m, i) => `<button type="button" class="chip person-chip ${i === 0 ? 'active' : ''}" data-id="${m.id}" data-name="${Utils.escapeHtml(m.name)}">${m.icon} ${Utils.escapeHtml(m.name)}</button>`).join('')}
        </div>
      </div>
      <div class="field">
        <label>ক্যাটাগরি</label>
        <div class="chip-row" id="exp-category-chips">
          ${categories.map((c, i) => `<button type="button" class="chip cat-chip ${i === 0 ? 'active' : ''}" data-name="${Utils.escapeHtml(c.name)}">${c.icon} ${Utils.escapeHtml(c.name)}</button>`).join('')}
          <button type="button" class="chip add-chip" id="add-category-chip">+ নতুন</button>
        </div>
      </div>
      <div class="field">
        <label>তারিখ</label>
        <input id="exp-date" type="date" value="${Utils.todayISO()}" max="${Utils.todayISO()}">
      </div>
      <div class="field">
        <label>পেমেন্ট পদ্ধতি</label>
        <select id="exp-payment">${Expenses.PAYMENT_METHODS.map(p => `<option value="${p}">${p}</option>`).join('')}</select>
      </div>
      <div class="field">
        <label>নোট (ঐচ্ছিক)</label>
        <textarea id="exp-note" placeholder="যেমন: মাছ ও সবজি"></textarea>
      </div>
      <div class="field">
        <label>রশিদের ছবি (ঐচ্ছিক)</label>
        <input id="exp-receipt" type="file" accept="image/*" capture="environment">
        <div id="exp-receipt-preview"></div>
      </div>
      <button class="btn btn-primary" id="save-expense-btn">সংরক্ষণ করুন</button>
    `;

    body.querySelectorAll('.person-chip').forEach(chip => chip.addEventListener('click', () => {
      body.querySelectorAll('.person-chip').forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
    }));
    body.querySelectorAll('.cat-chip').forEach(chip => chip.addEventListener('click', () => {
      body.querySelectorAll('.cat-chip').forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
    }));
    document.getElementById('add-category-chip').addEventListener('click', async () => {
      const name = prompt('নতুন ক্যাটাগরির নাম লিখুন:');
      if (!name) return;
      try {
        await Expenses.addCustomCategory(name);
        Utils.toast('ক্যাটাগরি যোগ করা হয়েছে', 'success');
        const cats = await Expenses.getAllCategories();
        renderExpenseForm(members, cats);
      } catch (err) { Utils.toast(err.message, 'error'); }
    });

    let receiptData = null;
    document.getElementById('exp-receipt').addEventListener('change', async (e) => {
      const file = e.target.files[0];
      if (!file) return;
      try {
        receiptData = await Utils.compressImage(file);
        document.getElementById('exp-receipt-preview').innerHTML = `<img src="${receiptData}" style="max-width:100%;border-radius:12px;margin-top:8px;">`;
      } catch (err) { Utils.toast('ছবি প্রক্রিয়াকরণে সমস্যা হয়েছে।', 'error'); }
    });

    document.getElementById('save-expense-btn').addEventListener('click', async () => {
      const amountField = document.getElementById('exp-amount');
      const v = Utils.validateAmount(amountField.value);
      const errEl = document.getElementById('exp-amount-error');
      if (!v.valid) {
        amountField.closest('.field').classList.add('has-error');
        errEl.textContent = v.msg;
        return;
      }
      amountField.closest('.field').classList.remove('has-error');

      const personChip = body.querySelector('.person-chip.active');
      const catChip = body.querySelector('.cat-chip.active');
      if (!personChip) { Utils.toast('ব্যক্তি নির্বাচন করুন।', 'error'); return; }
      if (!catChip) { Utils.toast('ক্যাটাগরি নির্বাচন করুন।', 'error'); return; }

      const date = document.getElementById('exp-date').value || Utils.todayISO();
      const payment = document.getElementById('exp-payment').value;
      const note = document.getElementById('exp-note').value.trim();

      try {
        await Expenses.add({
          amount: v.value, personId: personChip.dataset.id, personName: personChip.dataset.name,
          category: catChip.dataset.name, date, paymentMethod: payment, note, receipt: receiptData
        });
        document.getElementById('modal-root').innerHTML = '';
        Utils.toast('খরচ যোগ করা হয়েছে ✓', 'success');
        refreshDashboardBadge();
        if (currentRoute === 'expenses') Expenses.renderPage();
      } catch (err) {
        Utils.toast('ডেটা সংরক্ষণ করা যায়নি। আবার চেষ্টা করুন।', 'error');
      }
    });
  }

  function renderIncomeForm(members) {
    const body = document.getElementById('entry-form-body');
    body.innerHTML = `
      <div class="field">
        <label>পরিমাণ</label>
        <div class="amount-input-wrap"><span class="currency-sign">৳</span><input id="inc-amount" type="number" inputmode="decimal" placeholder="0" autofocus></div>
        <div class="error-text" id="inc-amount-error"></div>
      </div>
      <div class="field">
        <label>ব্যক্তি</label>
        <div class="chip-row" id="inc-person-chips">
          ${members.map((m, i) => `<button type="button" class="chip person-chip ${i === 0 ? 'active' : ''}" data-id="${m.id}" data-name="${Utils.escapeHtml(m.name)}">${m.icon} ${Utils.escapeHtml(m.name)}</button>`).join('')}
        </div>
      </div>
      <div class="field">
        <label>উৎস</label>
        <div class="chip-row">
          ${Income.SOURCES.map((s, i) => `<button type="button" class="chip source-chip ${i === 0 ? 'active' : ''}" data-name="${s}">${s}</button>`).join('')}
        </div>
      </div>
      <div class="field">
        <label>তারিখ</label>
        <input id="inc-date" type="date" value="${Utils.todayISO()}" max="${Utils.todayISO()}">
      </div>
      <div class="field">
        <label>নোট (ঐচ্ছিক)</label>
        <textarea id="inc-note" placeholder="বিস্তারিত লিখুন"></textarea>
      </div>
      <button class="btn btn-primary" id="save-income-btn">সংরক্ষণ করুন</button>
    `;

    body.querySelectorAll('.person-chip').forEach(chip => chip.addEventListener('click', () => {
      body.querySelectorAll('.person-chip').forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
    }));
    body.querySelectorAll('.source-chip').forEach(chip => chip.addEventListener('click', () => {
      body.querySelectorAll('.source-chip').forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
    }));

    document.getElementById('save-income-btn').addEventListener('click', async () => {
      const amountField = document.getElementById('inc-amount');
      const v = Utils.validateAmount(amountField.value);
      const errEl = document.getElementById('inc-amount-error');
      if (!v.valid) {
        amountField.closest('.field').classList.add('has-error');
        errEl.textContent = v.msg;
        return;
      }
      amountField.closest('.field').classList.remove('has-error');

      const personChip = body.querySelector('.person-chip.active');
      const sourceChip = body.querySelector('.source-chip.active');
      const date = document.getElementById('inc-date').value || Utils.todayISO();
      const note = document.getElementById('inc-note').value.trim();

      try {
        await Income.add({
          amount: v.value, personId: personChip ? personChip.dataset.id : '', personName: personChip ? personChip.dataset.name : '',
          source: sourceChip ? sourceChip.dataset.name : 'অন্যান্য', date, note
        });
        document.getElementById('modal-root').innerHTML = '';
        Utils.toast('আয় যোগ করা হয়েছে ✓', 'success');
        refreshDashboardBadge();
        if (currentRoute === 'income') Income.renderPage();
      } catch (err) {
        Utils.toast('ডেটা সংরক্ষণ করা যায়নি। আবার চেষ্টা করুন।', 'error');
      }
    });
  }

  // ---------------- Expense detail modal ----------------
  async function openExpenseDetail(id) {
    const e = await Expenses.getById(id);
    if (!e) return;
    const modalRoot = document.getElementById('modal-root');
    modalRoot.innerHTML = `
      <div class="modal-overlay" id="expense-detail-modal">
        <div class="modal-sheet">
          <div class="modal-drag-handle"></div>
          <div class="modal-header"><h2>খরচের বিবরণ</h2><button class="icon-btn" id="close-detail-modal">✕</button></div>
          ${e.receipt ? `<img src="${e.receipt}" style="width:100%;border-radius:14px;margin-bottom:14px;">` : ''}
          <div class="card">
            <div class="detail-row" style="display:flex;justify-content:space-between;padding:6px 0;"><span style="color:var(--muted);">ব্যক্তি</span><b>${Utils.escapeHtml(e.personName || '')}</b></div>
            <div class="detail-row" style="display:flex;justify-content:space-between;padding:6px 0;"><span style="color:var(--muted);">পরিমাণ</span><b style="color:var(--danger);">${Utils.fmtMoney(e.amount)}</b></div>
            <div class="detail-row" style="display:flex;justify-content:space-between;padding:6px 0;"><span style="color:var(--muted);">ক্যাটাগরি</span><b>${Utils.escapeHtml(e.category)}</b></div>
            <div class="detail-row" style="display:flex;justify-content:space-between;padding:6px 0;"><span style="color:var(--muted);">তারিখ</span><b>${Utils.fmtDateLong(e.date)}</b></div>
            <div class="detail-row" style="display:flex;justify-content:space-between;padding:6px 0;"><span style="color:var(--muted);">সময়</span><b>${Utils.fmtTime(e.time || e.createdAt)}</b></div>
            <div class="detail-row" style="display:flex;justify-content:space-between;padding:6px 0;"><span style="color:var(--muted);">পেমেন্ট</span><b>${Utils.escapeHtml(e.paymentMethod)}</b></div>
            ${e.note ? `<div class="detail-row" style="padding:6px 0;"><span style="color:var(--muted);">নোট</span><div style="margin-top:4px;">${Utils.escapeHtml(e.note)}</div></div>` : ''}
          </div>
          <div class="btn-block-row">
            <button class="btn btn-outline" id="edit-expense-btn">সম্পাদনা</button>
            <button class="btn btn-danger" id="delete-expense-btn">মুছে ফেলুন</button>
          </div>
        </div>
      </div>`;
    document.getElementById('close-detail-modal').addEventListener('click', () => modalRoot.innerHTML = '');
    document.getElementById('expense-detail-modal').addEventListener('click', (ev) => { if (ev.target.id === 'expense-detail-modal') modalRoot.innerHTML = ''; });
    document.getElementById('delete-expense-btn').addEventListener('click', async () => {
      const ok = await Utils.confirmDialog({ title: 'খরচ মুছবেন?', message: 'এই খরচের তথ্য স্থায়ীভাবে মুছে যাবে।', okText: 'মুছে ফেলুন' });
      if (ok) {
        await Expenses.remove(id);
        modalRoot.innerHTML = '';
        Utils.toast('মুছে ফেলা হয়েছে', 'success');
        refreshView();
      }
    });
    document.getElementById('edit-expense-btn').addEventListener('click', async () => {
      modalRoot.innerHTML = '';
      await openEditExpenseModal(e);
    });
  }

  async function openEditExpenseModal(e) {
    const modalRoot = document.getElementById('modal-root');
    const members = await Family.getAll();
    const categories = await Expenses.getAllCategories();
    modalRoot.innerHTML = `
      <div class="modal-overlay" id="edit-entry-modal">
        <div class="modal-sheet">
          <div class="modal-drag-handle"></div>
          <div class="modal-header"><h2>খরচ সম্পাদনা</h2><button class="icon-btn" id="close-edit-modal">✕</button></div>
          <div id="edit-form-body"></div>
        </div>
      </div>`;
    document.getElementById('close-edit-modal').addEventListener('click', () => modalRoot.innerHTML = '');
    document.getElementById('edit-entry-modal').addEventListener('click', (ev) => { if (ev.target.id === 'edit-entry-modal') modalRoot.innerHTML = ''; });

    const body = document.getElementById('edit-form-body');
    body.innerHTML = `
      <div class="field"><label>পরিমাণ</label>
        <div class="amount-input-wrap"><span class="currency-sign">৳</span><input id="edit-amount" type="number" value="${e.amount}"></div></div>
      <div class="field"><label>ব্যক্তি</label>
        <div class="chip-row">${members.map(m => `<button type="button" class="chip person-chip ${m.id === e.personId ? 'active' : ''}" data-id="${m.id}" data-name="${Utils.escapeHtml(m.name)}">${m.icon} ${Utils.escapeHtml(m.name)}</button>`).join('')}</div></div>
      <div class="field"><label>ক্যাটাগরি</label>
        <div class="chip-row">${categories.map(c => `<button type="button" class="chip cat-chip ${c.name === e.category ? 'active' : ''}" data-name="${Utils.escapeHtml(c.name)}">${c.icon} ${Utils.escapeHtml(c.name)}</button>`).join('')}</div></div>
      <div class="field"><label>তারিখ</label><input id="edit-date" type="date" value="${e.date}" max="${Utils.todayISO()}"></div>
      <div class="field"><label>পেমেন্ট পদ্ধতি</label>
        <select id="edit-payment">${Expenses.PAYMENT_METHODS.map(p => `<option value="${p}" ${p === e.paymentMethod ? 'selected' : ''}>${p}</option>`).join('')}</select></div>
      <div class="field"><label>নোট</label><textarea id="edit-note">${Utils.escapeHtml(e.note || '')}</textarea></div>
      <button class="btn btn-primary" id="update-expense-btn">হালনাগাদ করুন</button>
    `;
    body.querySelectorAll('.person-chip').forEach(chip => chip.addEventListener('click', () => { body.querySelectorAll('.person-chip').forEach(c => c.classList.remove('active')); chip.classList.add('active'); }));
    body.querySelectorAll('.cat-chip').forEach(chip => chip.addEventListener('click', () => { body.querySelectorAll('.cat-chip').forEach(c => c.classList.remove('active')); chip.classList.add('active'); }));

    document.getElementById('update-expense-btn').addEventListener('click', async () => {
      const v = Utils.validateAmount(document.getElementById('edit-amount').value);
      if (!v.valid) { Utils.toast(v.msg, 'error'); return; }
      const personChip = body.querySelector('.person-chip.active');
      const catChip = body.querySelector('.cat-chip.active');
      await Expenses.update(e.id, {
        amount: v.value,
        personId: personChip ? personChip.dataset.id : e.personId,
        personName: personChip ? personChip.dataset.name : e.personName,
        category: catChip ? catChip.dataset.name : e.category,
        date: document.getElementById('edit-date').value,
        paymentMethod: document.getElementById('edit-payment').value,
        note: document.getElementById('edit-note').value.trim()
      });
      modalRoot.innerHTML = '';
      Utils.toast('হালনাগাদ করা হয়েছে', 'success');
      refreshView();
    });
  }

  function refreshView() {
    navigate(currentRoute === 'searchResults' ? 'dashboard' : currentRoute);
  }

  // ---------------- PIN Lock ----------------
  function showPinLockScreen(onSuccess) {
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay center';
    overlay.id = 'pin-lock-overlay';
    overlay.innerHTML = `
      <div class="modal-sheet" style="text-align:center;">
        <div style="font-size:32px;margin-bottom:6px;">🔒</div>
        <h2>পিন দিয়ে আনলক করুন</h2>
        <div class="pin-dots" id="lock-pin-dots"></div>
        <div id="pin-error" style="color:var(--danger);font-size:13px;height:18px;"></div>
        <div class="pin-pad" id="lock-pin-pad"></div>
      </div>`;
    document.body.appendChild(overlay);

    let entered = '';
    const dotsEl = overlay.querySelector('#lock-pin-dots');
    const padEl = overlay.querySelector('#lock-pin-pad');
    const errEl = overlay.querySelector('#pin-error');

    function renderDots() {
      dotsEl.innerHTML = Array.from({ length: 6 }).map((_, i) => `<div class="pin-dot ${i < entered.length ? 'filled' : ''}" style="${i >= 4 && entered.length <= 4 ? 'display:none' : ''}"></div>`).join('');
    }
    renderDots();

    const keys = ['১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯', '', '০', '⌫'];
    padEl.innerHTML = keys.map((k, i) => k ? `<button class="pin-key" data-key="${i === 11 ? 'del' : '0123456789'[['১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯', '', '০'].indexOf(k)]}">${k}</button>` : `<div></div>`).join('');

    padEl.querySelectorAll('.pin-key').forEach(btn => {
      btn.addEventListener('click', async () => {
        if (btn.dataset.key === 'del') { entered = entered.slice(0, -1); renderDots(); errEl.textContent = ''; return; }
        if (entered.length >= 6) return;
        entered += btn.dataset.key;
        renderDots();
        if (entered.length >= 4) {
          const valid = await Settings.verifyPin(entered);
          if (valid) {
            overlay.remove();
            onSuccess();
          } else if (entered.length === 6) {
            errEl.textContent = 'ভুল পিন। আবার চেষ্টা করুন।';
            entered = ''; renderDots();
          }
        }
      });
    });
  }

  function openPinSetup() {
    const modalRoot = document.getElementById('modal-root');
    let step = 1;
    let firstPin = '';

    function render() {
      modalRoot.innerHTML = `
        <div class="modal-overlay center" id="pin-setup-modal">
          <div class="modal-sheet" style="text-align:center;">
            <div style="font-size:32px;margin-bottom:6px;">🔐</div>
            <h2>${step === 1 ? 'নতুন পিন সেট করুন' : 'পিন আবার লিখুন'}</h2>
            <div class="pin-dots" id="setup-pin-dots"></div>
            <div id="setup-pin-error" style="color:var(--danger);font-size:13px;height:18px;"></div>
            <div class="pin-pad" id="setup-pin-pad"></div>
            <button class="btn btn-secondary" id="cancel-pin-setup" style="margin-top:14px;">বাতিল</button>
          </div>
        </div>`;

      let entered = '';
      const dotsEl = document.getElementById('setup-pin-dots');
      const padEl = document.getElementById('setup-pin-pad');
      const errEl = document.getElementById('setup-pin-error');

      function renderDots() {
        dotsEl.innerHTML = Array.from({ length: 6 }).map((_, i) => `<div class="pin-dot ${i < entered.length ? 'filled' : ''}"></div>`).join('');
      }
      renderDots();

      const digitMap = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
      padEl.innerHTML = digitMap.slice(1).map((k, i) => `<button class="pin-key" data-key="${i + 1}">${k}</button>`).join('') +
        `<div></div><button class="pin-key" data-key="0">০</button><button class="pin-key" data-key="del">⌫</button>`;

      padEl.querySelectorAll('.pin-key').forEach(btn => {
        btn.addEventListener('click', async () => {
          if (btn.dataset.key === 'del') { entered = entered.slice(0, -1); renderDots(); return; }
          if (entered.length >= 6) return;
          entered += btn.dataset.key;
          renderDots();
          if (entered.length >= 4 && entered.length === 4) {
            // allow continuing to 6 digits or auto-confirm after short pause
          }
          if (entered.length === 6 || (entered.length >= 4 && entered.length === 4)) {
            // give a small window: auto proceed once 4+ digits entered and user pauses; simplest: proceed at 4 digits via explicit confirm button too.
          }
        });
      });

      // Simple confirm button appended below pad for 4-6 digit flexibility
      const confirmBtn = document.createElement('button');
      confirmBtn.className = 'btn btn-primary';
      confirmBtn.textContent = 'পরবর্তী';
      confirmBtn.style.marginTop = '14px';
      document.querySelector('#pin-setup-modal .modal-sheet').insertBefore(confirmBtn, document.getElementById('cancel-pin-setup'));

      confirmBtn.addEventListener('click', async () => {
        if (entered.length < 4) { errEl.textContent = 'কমপক্ষে ৪ সংখ্যার পিন দিন।'; return; }
        if (step === 1) {
          firstPin = entered;
          step = 2;
          render();
        } else {
          if (entered !== firstPin) {
            errEl.textContent = 'পিন মিলছে না। আবার চেষ্টা করুন।';
            entered = ''; renderDots();
            return;
          }
          await Settings.setPin(entered);
          modalRoot.innerHTML = '';
          Utils.toast('অ্যাপ লক চালু করা হয়েছে', 'success');
          Settings.renderPage();
        }
      });

      document.getElementById('cancel-pin-setup').addEventListener('click', () => modalRoot.innerHTML = '');
    }
    render();
  }

  // ---------------- Onboarding wizard ----------------
  function runOnboarding() {
    const container = document.getElementById('page-content');
    document.getElementById('app').classList.remove('hidden');
    document.querySelector('.bottom-nav').classList.add('hidden');
    document.querySelector('.fab').classList.add('hidden');
    document.querySelector('.topbar').classList.add('hidden');

    let step = 1;
    let headName = '';

    function renderStep() {
      if (step === 1) {
        container.innerHTML = `
          <div class="onboard-wrap">
            <div class="emoji">👋</div>
            <h2>স্বাগতম</h2>
            <p>আপনার পরিবারের খরচ সহজে পরিচালনা করুন।</p>
            <button class="btn btn-primary" id="ob-next">শুরু করুন</button>
            <div class="onboard-dots"><span class="active"></span><span></span><span></span></div>
          </div>`;
        document.getElementById('ob-next').addEventListener('click', () => { step = 2; renderStep(); });
      } else if (step === 2) {
        container.innerHTML = `
          <div class="onboard-wrap">
            <div class="emoji">👤</div>
            <h2>পরিবারের প্রধান সদস্যের নাম</h2>
            <div class="field" style="text-align:right;"><input id="ob-head-name" type="text" placeholder="যেমন: বাবা" value="বাবা"></div>
            <button class="btn btn-primary" id="ob-next2">পরবর্তী</button>
            <div class="onboard-dots"><span></span><span class="active"></span><span></span></div>
          </div>`;
        document.getElementById('ob-next2').addEventListener('click', () => {
          headName = document.getElementById('ob-head-name').value.trim() || 'বাবা';
          step = 3; renderStep();
        });
      } else if (step === 3) {
        container.innerHTML = `
          <div class="onboard-wrap">
            <div class="emoji">🎯</div>
            <h2>মাসিক আনুমানিক বাজেট</h2>
            <div class="field"><div class="amount-input-wrap"><span class="currency-sign">৳</span><input id="ob-budget" type="number" placeholder="৩০০০০" inputmode="decimal"></div></div>
            <button class="btn btn-primary" id="ob-finish">সম্পন্ন করুন</button>
            <div class="onboard-dots"><span></span><span></span><span class="active"></span></div>
          </div>`;
        document.getElementById('ob-finish').addEventListener('click', async () => {
          const budget = document.getElementById('ob-budget').value;
          await Family.update((await Family.getAll())[0].id, { name: headName });
          if (budget) await Budget.setOverallBudget(budget);
          await Settings.set('onboardingDone', true);
          finishOnboarding();
        });
      }
    }

    async function finishOnboarding() {
      document.querySelector('.bottom-nav').classList.remove('hidden');
      document.querySelector('.fab').classList.remove('hidden');
      document.querySelector('.topbar').classList.remove('hidden');
      bindNav();
      await navigate('dashboard');
      Utils.toast('আপনার অ্যাপ প্রস্তুত! 🎉', 'success');
    }

    renderStep();
  }

  // ---------------- Demo data ----------------
  async function generateDemoData() {
    const members = await Family.getAll();
    let memberList = members;
    if (memberList.length < 2) {
      await Family.add({ name: 'মা', icon: '👩', color: '#C77D2A' });
      memberList = await Family.getAll();
    }
    const categories = Expenses.DEFAULT_CATEGORIES;
    const paymentMethods = Expenses.PAYMENT_METHODS;

    for (let i = 0; i < 25; i++) {
      const daysAgo = Math.floor(Math.random() * 28);
      const date = new Date(); date.setDate(date.getDate() - daysAgo);
      const dateStr = date.toISOString().slice(0, 10);
      const member = memberList[Math.floor(Math.random() * memberList.length)];
      const cat = categories[Math.floor(Math.random() * categories.length)];
      const amount = Math.floor(Math.random() * 1500) + 50;
      await Expenses.add({
        amount, personId: member.id, personName: member.name, category: cat.name,
        date: dateStr, paymentMethod: paymentMethods[Math.floor(Math.random() * paymentMethods.length)],
        note: ''
      });
    }
    for (let i = 0; i < 3; i++) {
      const date = new Date(); date.setDate(1);
      const member = memberList[0];
      await Income.add({ amount: 25000 + i * 2000, personId: member.id, personName: member.name, source: 'বেতন', date: date.toISOString().slice(0, 10) });
    }
    await Savings.add({ title: 'জরুরি ফান্ড', target: 50000, saved: 15000, icon: '🎯' });
    await Debts.add({ personName: 'রহিম', amount: 2000, type: 'receivable' });
    await Debts.add({ personName: 'করিম', amount: 1500, type: 'payable' });
  }

  return {
    init, navigate, openExpenseDetail, openAddEntryModal, openMemberForm, openPinSetup,
    refreshDashboardBadge, generateDemoData, bindNav
  };
})();

document.addEventListener('DOMContentLoaded', () => App.init());
