/* ==========================================================================
   settings.js — App preferences, theme, PIN lock, settings page
   ========================================================================== */
'use strict';

const Settings = (() => {

  let cache = {};
  let loaded = false;

  async function loadAll() {
    if (loaded) return cache;
    const list = await DB.getAll('settings');
    cache = {};
    list.forEach(s => cache[s.key] = s.value);
    loaded = true;
    return cache;
  }

  function get(key, fallback = null) {
    return key in cache ? cache[key] : fallback;
  }

  async function set(key, value) {
    cache[key] = value;
    await DB.put('settings', { key, value });
  }

  // ---------------- Theme ----------------
  function applyTheme(theme) {
    const root = document.documentElement;
    if (theme === 'dark') root.setAttribute('data-theme', 'dark');
    else if (theme === 'light') root.removeAttribute('data-theme');
    else {
      const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
      if (prefersDark) root.setAttribute('data-theme', 'dark'); else root.removeAttribute('data-theme');
    }
  }

  async function initTheme() {
    const theme = get('theme', 'system');
    applyTheme(theme);
    if (theme === 'system' && window.matchMedia) {
      window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => {
        if (get('theme', 'system') === 'system') applyTheme('system');
      });
    }
  }

  // ---------------- PIN lock (Web Crypto hashing, never stored plain) ----------------
  async function sha256Hex(text) {
    const enc = new TextEncoder().encode(text);
    const buf = await crypto.subtle.digest('SHA-256', enc);
    return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
  }

  async function setPin(pin) {
    const hash = await sha256Hex(pin);
    await set('pinHash', hash);
    await set('pinEnabled', true);
  }

  async function verifyPin(pin) {
    const hash = await sha256Hex(pin);
    return hash === get('pinHash', null);
  }

  async function disablePin() {
    await set('pinEnabled', false);
    await set('pinHash', null);
  }

  function isPinEnabled() { return !!get('pinEnabled', false); }

  // ---------------- Settings page ----------------
  async function renderPage() {
    const container = document.getElementById('page-content');
    const theme = get('theme', 'system');
    const currency = get('currency', 'BDT');
    const numeralStyle = get('numeralStyle', 'bn');
    const pinOn = isPinEnabled();

    container.innerHTML = `
      <div class="card">
        <div class="section-title">থিম</div>
        <div class="chip-row">
          <button class="chip ${theme === 'light' ? 'active' : ''}" data-theme="light">লাইট</button>
          <button class="chip ${theme === 'dark' ? 'active' : ''}" data-theme="dark">ডার্ক</button>
          <button class="chip ${theme === 'system' ? 'active' : ''}" data-theme="system">সিস্টেম</button>
        </div>
      </div>

      <div class="card">
        <div class="section-title">সংখ্যা পদ্ধতি</div>
        <div class="chip-row">
          <button class="chip ${numeralStyle === 'bn' ? 'active' : ''}" data-num="bn">বাংলা সংখ্যা (১২৩)</button>
          <button class="chip ${numeralStyle === 'en' ? 'active' : ''}" data-num="en">ইংরেজি সংখ্যা (123)</button>
        </div>
      </div>

      <div class="card">
        <div class="section-title">মুদ্রা</div>
        <div class="hint" style="color:var(--muted);">৳ (BDT) — বাংলাদেশি টাকা</div>
      </div>

      <div class="card">
        <div class="section-title">অ্যাপ লক <span class="badge ${pinOn ? 'pin-on' : ''}">${pinOn ? 'চালু' : 'বন্ধ'}</span></div>
        <div class="hint" style="color:var(--muted);margin-bottom:10px;">অ্যাপ খোলার সময় ৪-৬ সংখ্যার পিন কোড চাইবে।</div>
        <button class="btn ${pinOn ? 'btn-secondary' : 'btn-primary'}" id="toggle-pin-btn">${pinOn ? 'পিন লক বন্ধ করুন' : 'পিন লক চালু করুন'}</button>
      </div>

      <div class="card">
        <div class="section-title">ডেটা ব্যবস্থাপনা</div>
        <div style="display:flex;flex-direction:column;gap:10px;">
          <button class="btn btn-outline" id="backup-btn">📤 ব্যাকআপ ডাউনলোড করুন</button>
          <button class="btn btn-outline" id="restore-btn">📥 ব্যাকআপ পুনরুদ্ধার করুন</button>
          <input type="file" id="restore-file-input" accept=".json,application/json" class="hidden">
          <button class="btn btn-outline" id="csv-export-btn">📄 CSV ডাউনলোড করুন</button>
          <button class="btn btn-outline" id="pdf-export-btn">🧾 PDF রিপোর্ট তৈরি করুন</button>
          <button class="btn btn-outline" id="demo-data-btn">✨ ডেমো ডেটা যোগ করুন</button>
          <button class="btn btn-danger" id="clear-data-btn">🗑️ সব ডেটা মুছে ফেলুন</button>
        </div>
      </div>

      <div class="card" style="text-align:center;">
        <div style="font-size:32px;margin-bottom:6px;">৳</div>
        <div style="font-weight:800;">পারিবারিক খরচ ম্যানেজার</div>
        <div style="color:var(--muted);font-size:13px;margin-top:4px;">আপনার পরিবারের আয়-ব্যয়ের সহজ ব্যবস্থাপনা।</div>
        <div style="color:var(--muted);font-size:12px;margin-top:8px;">সংস্করণ ১.০.০</div>
      </div>
    `;

    container.querySelectorAll('[data-theme]').forEach(btn => {
      btn.addEventListener('click', async () => {
        await set('theme', btn.dataset.theme);
        applyTheme(btn.dataset.theme);
        renderPage();
      });
    });
    container.querySelectorAll('[data-num]').forEach(btn => {
      btn.addEventListener('click', async () => {
        await set('numeralStyle', btn.dataset.num);
        renderPage();
        App.refreshDashboardBadge();
      });
    });

    document.getElementById('toggle-pin-btn').addEventListener('click', async () => {
      if (pinOn) {
        const ok = await Utils.confirmDialog({ title: 'পিন লক বন্ধ করবেন?', message: 'অ্যাপ খোলার সময় আর পিন চাইবে না।', okText: 'বন্ধ করুন' });
        if (ok) { await disablePin(); Utils.toast('পিন লক বন্ধ করা হয়েছে', 'success'); renderPage(); }
      } else {
        App.openPinSetup();
      }
    });

    document.getElementById('backup-btn').addEventListener('click', () => Backup.exportJson());
    document.getElementById('restore-btn').addEventListener('click', () => document.getElementById('restore-file-input').click());
    document.getElementById('restore-file-input').addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (file) Backup.importJson(file);
      e.target.value = '';
    });
    document.getElementById('csv-export-btn').addEventListener('click', () => Backup.exportCsv());
    document.getElementById('pdf-export-btn').addEventListener('click', () => PDFReport.generate());
    document.getElementById('demo-data-btn').addEventListener('click', async () => {
      const ok = await Utils.confirmDialog({ title: 'ডেমো ডেটা যোগ করবেন?', message: 'পরীক্ষার জন্য কিছু নমুনা তথ্য যোগ করা হবে।', okText: 'যোগ করুন', danger: false });
      if (ok) { await App.generateDemoData(); Utils.toast('ডেমো ডেটা যোগ করা হয়েছে', 'success'); App.navigate('dashboard'); }
    });
    document.getElementById('clear-data-btn').addEventListener('click', async () => {
      const ok = await Utils.confirmDialog({ title: 'সব ডেটা মুছে ফেলবেন?', message: 'এই কাজটি ফিরিয়ে আনা যাবে না। সব খরচ, আয়, সদস্য ও সেটিংস মুছে যাবে।', okText: 'সব মুছে ফেলুন' });
      if (ok) {
        const ok2 = await Utils.confirmDialog({ title: 'আপনি কি একদম নিশ্চিত?', message: 'এটি একটি চূড়ান্ত সিদ্ধান্ত। ব্যাকআপ ছাড়া ডেটা পুনরুদ্ধার সম্ভব নয়।', okText: 'হ্যাঁ, সব মুছুন' });
        if (ok2) {
          await DB.clearAll();
          loaded = false; cache = {};
          Utils.toast('সব ডেটা মুছে ফেলা হয়েছে', 'success');
          location.reload();
        }
      }
    });
  }

  return { loadAll, get, set, applyTheme, initTheme, setPin, verifyPin, disablePin, isPinEnabled, sha256Hex, renderPage };
})();
