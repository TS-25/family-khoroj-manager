/* ==========================================================================
   backup.js — JSON backup/restore and CSV export
   ========================================================================== */
'use strict';

const Backup = (() => {

  async function exportJson() {
    try {
      const data = await DB.exportAll();
      const json = JSON.stringify(data, null, 2);
      const blob = new Blob([json], { type: 'application/json' });
      const filename = `family-khoroj-backup-${Utils.todayISO()}.json`;
      Utils.downloadBlob(blob, filename);
      Utils.toast('ব্যাকআপ ডাউনলোড হয়েছে', 'success');
    } catch (err) {
      console.error(err);
      Utils.toast('ব্যাকআপ তৈরি করা যায়নি। আবার চেষ্টা করুন।', 'error');
    }
  }

  async function importJson(file) {
    try {
      if (!file.name.toLowerCase().endsWith('.json')) {
        Utils.toast('দয়া করে একটি বৈধ JSON ফাইল নির্বাচন করুন।', 'error');
        return;
      }
      const text = await file.text();
      let data;
      try { data = JSON.parse(text); } catch (e) { throw new Error('ফাইলটি সঠিক JSON ফরম্যাটে নেই।'); }

      // Basic structural validation before touching the database.
      const knownStores = Object.keys(DB.STORES);
      const hasKnownStore = knownStores.some(k => Array.isArray(data[k]));
      if (!hasKnownStore) throw new Error('এটি একটি বৈধ ব্যাকআপ ফাইল নয়।');

      const ok = await Utils.confirmDialog({
        title: 'ডেটা পুনরুদ্ধার করবেন?',
        message: 'বর্তমান সমস্ত ডেটা মুছে গিয়ে ব্যাকআপ ফাইলের ডেটা দিয়ে প্রতিস্থাপিত হবে।',
        okText: 'পুনরুদ্ধার করুন'
      });
      if (!ok) return;

      await DB.importAll(data);
      Utils.toast('ডেটা সফলভাবে পুনরুদ্ধার করা হয়েছে', 'success');
      setTimeout(() => location.reload(), 800);
    } catch (err) {
      console.error(err);
      Utils.toast(err.message || 'ব্যাকআপ পুনরুদ্ধার করা যায়নি। আবার চেষ্টা করুন।', 'error');
    }
  }

  function csvEscape(val) {
    if (val === null || val === undefined) return '';
    const s = String(val).replace(/"/g, '""');
    return /[",\n]/.test(s) ? `"${s}"` : s;
  }

  async function exportCsv() {
    try {
      const expenses = await Expenses.getAll();
      if (expenses.length === 0) { Utils.toast('কোনো খরচ পাওয়া যায়নি।', 'warning'); return; }
      const header = ['তারিখ', 'সময়', 'ব্যক্তি', 'ক্যাটাগরি', 'পরিমাণ', 'পেমেন্ট', 'নোট'];
      const rows = expenses.map(e => [
        e.date, Utils.fmtTime(e.time || e.createdAt), e.personName || '', e.category, e.amount, e.paymentMethod, e.note || ''
      ]);
      const csvLines = [header, ...rows].map(r => r.map(csvEscape).join(','));
      const csvContent = '\uFEFF' + csvLines.join('\r\n'); // BOM for correct Bangla display in Excel
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      Utils.downloadBlob(blob, `family-khoroj-expenses-${Utils.todayISO()}.csv`);
      Utils.toast('CSV ফাইল ডাউনলোড হয়েছে', 'success');
    } catch (err) {
      console.error(err);
      Utils.toast('CSV তৈরি করা যায়নি। আবার চেষ্টা করুন।', 'error');
    }
  }

  return { exportJson, importJson, exportCsv };
})();
