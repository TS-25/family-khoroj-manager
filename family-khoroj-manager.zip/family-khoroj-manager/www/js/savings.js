/* ==========================================================================
   savings.js — Savings goals tracking
   ========================================================================== */
'use strict';

const Savings = (() => {

  async function getAll() {
    const list = await DB.getAll('savingsGoals');
    return list.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  }

  async function getById(id) { return DB.get('savingsGoals', id); }

  async function add({ title, target, saved = 0, icon = '🎯' }) {
    title = (title || '').trim();
    if (!title) throw new Error('লক্ষ্যের নাম আবশ্যক।');
    const now = Utils.nowISO();
    const record = { id: Utils.uuid(), title, icon, target: Number(target) || 0, saved: Number(saved) || 0, createdAt: now, updatedAt: now };
    await DB.put('savingsGoals', record);
    return record;
  }

  async function update(id, patch) {
    const existing = await DB.get('savingsGoals', id);
    if (!existing) throw new Error('লক্ষ্য পাওয়া যায়নি।');
    const updated = { ...existing, ...patch, updatedAt: Utils.nowISO() };
    await DB.put('savingsGoals', updated);
    return updated;
  }

  async function addContribution(id, amount) {
    const existing = await DB.get('savingsGoals', id);
    if (!existing) throw new Error('লক্ষ্য পাওয়া যায়নি।');
    return update(id, { saved: Number(existing.saved) + Number(amount) });
  }

  async function remove(id) { await DB.remove('savingsGoals', id); }

  function totalSaved(list) { return list.reduce((s, g) => s + Number(g.saved || 0), 0); }

  async function renderPage() {
    const container = document.getElementById('page-content');
    const list = await getAll();

    container.innerHTML = `
      <div class="section-title">সঞ্চয় লক্ষ্যসমূহ
        <button class="btn btn-sm btn-primary" id="add-goal-btn">+ নতুন লক্ষ্য</button>
      </div>
      <div id="goals-list"></div>
    `;

    const listEl = document.getElementById('goals-list');
    if (list.length === 0) {
      listEl.innerHTML = `<div class="empty-state"><div class="icon">🎯</div><div class="title">কোনো সঞ্চয় লক্ষ্য নেই</div><div class="desc">নতুন লক্ষ্য যোগ করুন এবং সঞ্চয় শুরু করুন</div></div>`;
    } else {
      listEl.innerHTML = list.map(g => {
        const pct = g.target > 0 ? Math.min(100, Math.round((g.saved / g.target) * 100)) : 0;
        const remaining = Math.max(0, g.target - g.saved);
        return `
        <div class="card" data-id="${g.id}">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
            <div style="font-weight:700;">${g.icon} ${Utils.escapeHtml(g.title)}</div>
            <button class="btn btn-sm btn-outline add-contrib-btn">টাকা জমা দিন</button>
          </div>
          <div class="progress-track"><div class="progress-fill" style="width:${pct}%"></div></div>
          <div style="display:flex;justify-content:space-between;font-size:12.5px;color:var(--muted);margin-top:6px;">
            <span>জমা: ${Utils.fmtMoney(g.saved)}</span><span>লক্ষ্য: ${Utils.fmtMoney(g.target)}</span>
          </div>
          <div style="font-size:12px;color:var(--muted);margin-top:2px;">বাকি: ${Utils.fmtMoney(remaining)}</div>
          <div class="btn-block-row" style="margin-top:10px;">
            <button class="btn btn-sm btn-outline edit-goal-btn" style="flex:1;">সম্পাদনা</button>
            <button class="btn btn-sm btn-danger delete-goal-btn" style="flex:1;">মুছে ফেলুন</button>
          </div>
        </div>`;
      }).join('');
    }

    document.getElementById('add-goal-btn').addEventListener('click', () => openGoalForm());
    listEl.querySelectorAll('.add-contrib-btn').forEach(btn => btn.addEventListener('click', (e) => {
      const id = e.target.closest('[data-id]').dataset.id;
      const val = prompt('কত টাকা জমা দিতে চান?');
      if (val === null) return;
      const v = Utils.validateAmount(val);
      if (!v.valid) { Utils.toast(v.msg, 'error'); return; }
      addContribution(id, v.value).then(() => { Utils.toast('জমা সংরক্ষণ করা হয়েছে', 'success'); renderPage(); });
    }));
    listEl.querySelectorAll('.edit-goal-btn').forEach(btn => btn.addEventListener('click', (e) => {
      const id = e.target.closest('[data-id]').dataset.id;
      getById(id).then(goal => openGoalForm(goal));
    }));
    listEl.querySelectorAll('.delete-goal-btn').forEach(btn => btn.addEventListener('click', async (e) => {
      const id = e.target.closest('[data-id]').dataset.id;
      const ok = await Utils.confirmDialog({ title: 'লক্ষ্য মুছবেন?', message: 'এই সঞ্চয় লক্ষ্যটি স্থায়ীভাবে মুছে যাবে।', okText: 'মুছে ফেলুন' });
      if (ok) { await remove(id); Utils.toast('মুছে ফেলা হয়েছে', 'success'); renderPage(); }
    }));
  }

  function openGoalForm(goal = null) {
    const modalRoot = document.getElementById('modal-root');
    modalRoot.innerHTML = `
      <div class="modal-overlay" id="goal-modal">
        <div class="modal-sheet">
          <div class="modal-drag-handle"></div>
          <div class="modal-header"><h2>${goal ? 'লক্ষ্য সম্পাদনা' : 'নতুন সঞ্চয় লক্ষ্য'}</h2>
            <button class="icon-btn" id="close-goal-modal">✕</button></div>
          <div class="field"><label>লক্ষ্যের নাম</label><input id="goal-title" type="text" placeholder="যেমন: নতুন ফোন" value="${goal ? Utils.escapeHtml(goal.title) : ''}"></div>
          <div class="field"><label>লক্ষ্য পরিমাণ</label>
            <div class="amount-input-wrap"><span class="currency-sign">৳</span>
            <input id="goal-target" type="number" inputmode="decimal" value="${goal ? goal.target : ''}"></div></div>
          <div class="field"><label>বর্তমান জমা</label>
            <div class="amount-input-wrap"><span class="currency-sign">৳</span>
            <input id="goal-saved" type="number" inputmode="decimal" value="${goal ? goal.saved : 0}"></div></div>
          <button class="btn btn-primary" id="save-goal-btn">সংরক্ষণ করুন</button>
        </div>
      </div>`;
    document.getElementById('close-goal-modal').addEventListener('click', () => modalRoot.innerHTML = '');
    document.getElementById('goal-modal').addEventListener('click', (e) => { if (e.target.id === 'goal-modal') modalRoot.innerHTML = ''; });
    document.getElementById('save-goal-btn').addEventListener('click', async () => {
      const title = document.getElementById('goal-title').value.trim();
      const target = document.getElementById('goal-target').value;
      const saved = document.getElementById('goal-saved').value || 0;
      if (!title) { Utils.toast('লক্ষ্যের নাম লিখুন।', 'error'); return; }
      const tv = Utils.validateAmount(target);
      if (!tv.valid) { Utils.toast(tv.msg, 'error'); return; }
      try {
        if (goal) await update(goal.id, { title, target: tv.value, saved: Number(saved) || 0 });
        else await add({ title, target: tv.value, saved: Number(saved) || 0 });
        modalRoot.innerHTML = '';
        Utils.toast('সংরক্ষণ করা হয়েছে', 'success');
        renderPage();
      } catch (err) { Utils.toast(err.message || 'একটি সমস্যা হয়েছে।', 'error'); }
    });
  }

  return { getAll, getById, add, update, addContribution, remove, totalSaved, renderPage, openGoalForm };
})();
