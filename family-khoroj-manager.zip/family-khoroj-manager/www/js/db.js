/* ==========================================================================
   db.js — IndexedDB data layer
   Stores: familyMembers, expenses, income, categories, budgets,
           savingsGoals, debts, settings
   ========================================================================== */
'use strict';

const DB = (() => {
  const DB_NAME = 'familyKhorojDB';
  const DB_VERSION = 1;
  let dbInstance = null;

  const STORES = {
    familyMembers: 'id',
    expenses: 'id',
    income: 'id',
    categories: 'id',
    budgets: 'id',
    savingsGoals: 'id',
    debts: 'id',
    settings: 'key'
  };

  function open() {
    if (dbInstance) return Promise.resolve(dbInstance);
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VERSION);

      req.onupgradeneeded = (event) => {
        const db = event.target.result;
        Object.entries(STORES).forEach(([name, keyPath]) => {
          if (!db.objectStoreNames.contains(name)) {
            const store = db.createObjectStore(name, { keyPath });
            if (name === 'expenses') {
              store.createIndex('date', 'date', { unique: false });
              store.createIndex('personId', 'personId', { unique: false });
              store.createIndex('category', 'category', { unique: false });
            }
            if (name === 'income') {
              store.createIndex('date', 'date', { unique: false });
            }
          }
        });
      };

      req.onsuccess = (event) => { dbInstance = event.target.result; resolve(dbInstance); };
      req.onerror = (event) => reject(event.target.error);
    });
  }

  async function tx(storeName, mode = 'readonly') {
    const db = await open();
    const transaction = db.transaction(storeName, mode);
    return transaction.objectStore(storeName);
  }

  function reqToPromise(req) {
    return new Promise((resolve, reject) => {
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  async function getAll(storeName) {
    const store = await tx(storeName);
    return reqToPromise(store.getAll());
  }

  async function get(storeName, id) {
    const store = await tx(storeName);
    return reqToPromise(store.get(id));
  }

  async function put(storeName, record) {
    const store = await tx(storeName, 'readwrite');
    return reqToPromise(store.put(record));
  }

  async function bulkPut(storeName, records) {
    const db = await open();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(storeName, 'readwrite');
      const store = transaction.objectStore(storeName);
      records.forEach(r => store.put(r));
      transaction.oncomplete = () => resolve(true);
      transaction.onerror = () => reject(transaction.error);
    });
  }

  async function remove(storeName, id) {
    const store = await tx(storeName, 'readwrite');
    return reqToPromise(store.delete(id));
  }

  async function clearStore(storeName) {
    const store = await tx(storeName, 'readwrite');
    return reqToPromise(store.clear());
  }

  async function clearAll() {
    for (const name of Object.keys(STORES)) {
      await clearStore(name);
    }
  }

  async function exportAll() {
    const data = {};
    for (const name of Object.keys(STORES)) {
      data[name] = await getAll(name);
    }
    data.__meta = { exportedAt: Utils.nowISO(), version: DB_VERSION, app: 'family-khoroj-manager' };
    return data;
  }

  async function importAll(data) {
    if (!data || typeof data !== 'object') throw new Error('অবৈধ ব্যাকআপ ফাইল।');
    const validStores = Object.keys(STORES);
    const foundAny = validStores.some(name => Array.isArray(data[name]));
    if (!foundAny) throw new Error('ব্যাকআপ ফাইলে কোনো বৈধ ডেটা পাওয়া যায়নি।');
    await clearAll();
    for (const name of validStores) {
      if (Array.isArray(data[name])) {
        await bulkPut(name, data[name]);
      }
    }
    return true;
  }

  return { open, getAll, get, put, bulkPut, remove, clearStore, clearAll, exportAll, importAll, STORES };
})();
