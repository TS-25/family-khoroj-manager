/* ==========================================================================
   pdf.js — Client-side PDF report generation.
   Bangla text does not render reliably with jsPDF's built-in fonts, so we
   render the report as styled HTML, rasterize it with html2canvas (which
   uses the browser's own font engine and therefore draws Bangla glyphs
   correctly), then place that image into a multi-page jsPDF document.
   ========================================================================== */
'use strict';

const PDFReport = (() => {

  async function buildReportHtml(range = 'month') {
    const { start, end } = Utils.startEndOfRange(range);
    const allExpenses = await Expenses.getAll();
    const allIncome = await Income.getAll();

    const expenses = allExpenses.filter(e => {
      const d = new Date(e.date + 'T12:00:00');
      return d >= new Date(start) && d <= new Date(end);
    });
    const income = allIncome.filter(i => {
      const d = new Date(i.date + 'T12:00:00');
      return d >= new Date(start) && d <= new Date(end);
    });

    const totalIncome = Income.sum(income);
    const totalExpense = Expenses.sum(expenses);
    const savings = totalIncome - totalExpense;

    const byCategory = {};
    expenses.forEach(e => { byCategory[e.category] = (byCategory[e.category] || 0) + Number(e.amount); });
    const catRows = Object.entries(byCategory).sort((a, b) => b[1] - a[1]);

    const byPerson = {};
    expenses.forEach(e => { const k = e.personName || 'অজানা'; byPerson[k] = (byPerson[k] || 0) + Number(e.amount); });
    const personRows = Object.entries(byPerson).sort((a, b) => b[1] - a[1]);

    const rangeLabelStart = Utils.fmtDateLong(start);
    const rangeLabelEnd = Utils.fmtDateLong(end);

    return `
      <div style="font-family:'Noto Sans Bengali','Hind Siliguri',sans-serif;width:760px;padding:30px;color:#17201C;">
        <h1 style="font-size:24px;margin:0 0 4px;">পারিবারিক খরচের রিপোর্ট</h1>
        <div style="color:#555;margin-bottom:20px;">সময়কাল: ${rangeLabelStart} - ${rangeLabelEnd}</div>

        <table style="width:100%;border-collapse:collapse;margin-bottom:24px;">
          <tr>
            <td style="background:#E6F4EC;padding:14px;border-radius:8px;width:33%;text-align:center;">
              <div style="font-size:12px;color:#555;">মোট আয়</div><div style="font-size:18px;font-weight:800;color:#2E7D5B;">৳ ${Utils.fmtNumber(totalIncome)}</div>
            </td>
            <td style="width:2%;"></td>
            <td style="background:#FBE7E7;padding:14px;border-radius:8px;width:33%;text-align:center;">
              <div style="font-size:12px;color:#555;">মোট খরচ</div><div style="font-size:18px;font-weight:800;color:#D64545;">৳ ${Utils.fmtNumber(totalExpense)}</div>
            </td>
            <td style="width:2%;"></td>
            <td style="background:#FCEEDF;padding:14px;border-radius:8px;width:33%;text-align:center;">
              <div style="font-size:12px;color:#555;">সঞ্চয়</div><div style="font-size:18px;font-weight:800;color:#C77D2A;">৳ ${Utils.fmtNumber(savings)}</div>
            </td>
          </tr>
        </table>

        <h2 style="font-size:16px;border-bottom:2px solid #2E7D5B;padding-bottom:6px;">ক্যাটাগরি অনুযায়ী খরচ</h2>
        <table style="width:100%;border-collapse:collapse;margin-bottom:20px;font-size:13px;">
          ${catRows.map(([cat, amt]) => `
            <tr><td style="padding:6px 0;border-bottom:1px solid #eee;">${Utils.escapeHtml(cat)}</td>
                <td style="padding:6px 0;border-bottom:1px solid #eee;text-align:right;font-weight:700;">৳ ${Utils.fmtNumber(amt)}</td></tr>`).join('') || '<tr><td>কোনো তথ্য নেই</td></tr>'}
        </table>

        <h2 style="font-size:16px;border-bottom:2px solid #2E7D5B;padding-bottom:6px;">ব্যক্তি অনুযায়ী খরচ</h2>
        <table style="width:100%;border-collapse:collapse;margin-bottom:20px;font-size:13px;">
          ${personRows.map(([p, amt]) => `
            <tr><td style="padding:6px 0;border-bottom:1px solid #eee;">${Utils.escapeHtml(p)}</td>
                <td style="padding:6px 0;border-bottom:1px solid #eee;text-align:right;font-weight:700;">৳ ${Utils.fmtNumber(amt)}</td></tr>`).join('') || '<tr><td>কোনো তথ্য নেই</td></tr>'}
        </table>

        <h2 style="font-size:16px;border-bottom:2px solid #2E7D5B;padding-bottom:6px;">খরচের তালিকা (${Utils.fmtNumber(expenses.length)}টি)</h2>
        <table style="width:100%;border-collapse:collapse;font-size:12px;">
          <tr style="background:#F0F2F1;">
            <th style="padding:6px;text-align:right;">তারিখ</th><th style="padding:6px;text-align:right;">ব্যক্তি</th>
            <th style="padding:6px;text-align:right;">ক্যাটাগরি</th><th style="padding:6px;text-align:right;">পরিমাণ</th>
          </tr>
          ${expenses.slice(0, 200).map(e => `
            <tr><td style="padding:5px;border-bottom:1px solid #eee;text-align:right;">${Utils.fmtDateShort(e.date)}</td>
                <td style="padding:5px;border-bottom:1px solid #eee;text-align:right;">${Utils.escapeHtml(e.personName || '')}</td>
                <td style="padding:5px;border-bottom:1px solid #eee;text-align:right;">${Utils.escapeHtml(e.category)}</td>
                <td style="padding:5px;border-bottom:1px solid #eee;text-align:right;font-weight:700;">৳ ${Utils.fmtNumber(e.amount)}</td></tr>`).join('')}
        </table>

        <div style="margin-top:24px;color:#888;font-size:11px;text-align:center;">পারিবারিক খরচ ম্যানেজার দ্বারা তৈরি — ${Utils.fmtDateLong(Utils.nowISO())}</div>
      </div>
    `;
  }

  async function generate(range = 'month') {
    if (typeof window.jspdf === 'undefined' || typeof window.html2canvas === 'undefined') {
      Utils.toast('PDF তৈরির জন্য ইন্টারনেট সংযোগ প্রয়োজন (একবার লোড হওয়ার পর অফলাইনেও কাজ করবে)।', 'warning');
      return;
    }
    Utils.toast('রিপোর্ট তৈরি হচ্ছে...', 'default', 2000);
    try {
      const printArea = document.getElementById('print-area');
      printArea.innerHTML = await buildReportHtml(range);
      printArea.style.left = '0px'; printArea.style.top = '0px'; printArea.style.zIndex = '-1'; printArea.style.opacity = '0';

      const canvas = await html2canvas(printArea, { scale: 2, backgroundColor: '#ffffff' });
      const imgData = canvas.toDataURL('image/jpeg', 0.92);

      const { jsPDF } = window.jspdf;
      const pdf = new jsPDF('p', 'pt', 'a4');
      const pageWidth = pdf.internal.pageSize.getWidth();
      const pageHeight = pdf.internal.pageSize.getHeight();
      const imgWidth = pageWidth;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;

      let heightLeft = imgHeight;
      let position = 0;

      pdf.addImage(imgData, 'JPEG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;

      while (heightLeft > 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'JPEG', 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;
      }

      pdf.save(`family-khoroj-report-${Utils.todayISO()}.pdf`);
      printArea.innerHTML = ''; printArea.style.left = '-9999px'; printArea.style.top = '-9999px';
      Utils.toast('PDF রিপোর্ট ডাউনলোড হয়েছে', 'success');
    } catch (err) {
      console.error(err);
      Utils.toast('PDF তৈরি করা যায়নি। আবার চেষ্টা করুন।', 'error');
    }
  }

  return { generate, buildReportHtml };
})();
