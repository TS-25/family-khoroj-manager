/* ==========================================================================
   expenses.js — Expense CRUD, categories, daily/calendar views
   ========================================================================== */
'use strict';

const Expenses = (() => {

  const DEFAULT_CATEGORIES = [
    { name: 'বাজার', icon: '🛒' }, { name: 'খাবার', icon: '🍽️' }, { name: 'যাতায়াত', icon: '🚌' },
    { name: 'শিক্ষা', icon: '📚' }, { name: 'স্বাস্থ্য', icon: '💊' }, { name: 'বিদ্যুৎ', icon: '💡' },
    { name: 'গ্যাস', icon: '🔥' }, { name: 'পানি', icon: '🚰' }, { name: 'ইন্টারনেট', icon: '🌐' },
    { name: 'মোবাইল', icon: '📱' }, { name: 'পোশাক', icon: '👕' }, { name: 'বাসা ভাড়া', icon: '🏠' },
    { name: 'বিনোদন', icon: '🎬' }, { name: 'বিল', icon: '🧾' }, { name: 'অন্যান্য', icon: '📦' }
  ];

  const PAYMENT_METHODS = ['নগদ', 'বিকাশ', 'নগদ অ্যাপ', 'ব্যাংক', 'কার্ড', 'অন্যান্য'];

  async function seedDefaultCategoriesIfEmpty() {
    const existing = await DB.getAll('categories');
    if (existing.length === 0) {
      for (const c of DEFAULT_CATEGORIES) {
        await DB.put('categories', { id: Utils.uuid(), name: c.name, icon: c.icon, custom: false, createdAt: Utils.nowISO() });
      }
    }
  }

  async function getAllCategories() {
    const list = await DB.getAll('categories');
    return list.sort((a, b) => (a.custom === b.custom) ? 0 : (a.custom ? 1 : -1));
  }

  async function addCustomCategory(name) {
    name = (name || '').trim();
    if (!name) throw new Error('ক্যাটাগরির নাম আবশ্যক।');
    const record = { id: Utils.uuid(), name, icon: '🏷️', custom: true, createdAt: Utils.nowISO() };
    await DB.put('categories', record);
    return record;
  }

  async function getAll() {
    const list = await DB.getAll('expenses');
    return list.sort((a, b) => new Date(b.date) - new Date(a.date));
  }

  async function getById(id) { return DB.get('expenses', id); }

  async function add(data) {
    const now = Utils.nowISO();
    const record = {
      id: Utils.uuid(),
      amount: Number(data.amount),
      personId: data.personId,
      personName: data.personName,
      category: data.category,
      date: data.date || Utils.todayISO(),
      time: data.time || now,
      paymentMethod: data.paymentMethod || 'নগদ',
      note: data.note || '',
      receipt: data.receipt || null,
      createdAt: now, updatedAt: now
    };
    await DB.put('expenses', record);
    return record;
  }

  async function update(id, patch) {
    const existing = await DB.get('expenses', id);
    if (!existing) throw new Error('খরচ পাওয়া যায়নি।');
    const updated = { ...existing, ...patch, updatedAt: Utils.nowISO() };
    await DB.put('expenses', updated);
    return updated;
  }

  async function remove(id) { await DB.remove('expenses', id); }

  async function getInRange(startISO, endISO) {
    const all = await getAll();
    return all.filter(e => e.date >= startISO.slice(0, 10) ? true : new Date(e.date) >= new Date(startISO) && new Date(e.date) <= new Date(endISO)) 
      .filter(e => new Date(e.date + 'T12:00:00') >= new Date(startISO) && new Date(e.date + 'T12:00:00') <= new Date(endISO));
  }

  async function getByMonth(monthKey) {
    const all = await getAll();
    return all.filter(e => Utils.monthKey(e.date) === monthKey);
  }

  async function getToday() {
    const all = await getAll();
    return all.filter(e => e.date === Utils.todayISO());
  }

  function sum(list) { return list.reduce((s, e) => s + Number(e.amount || 0), 0); }

  async function search(query, filters = {}) {
    let list = await getAll();
    if (filters.range) {
      const { start, end } = Utils.startEndOfRange(filters.range);
      list = list.filter(e => {
        const d = new Date(e.date + 'T12:00:00');
        return d >= new Date(start) && d <= new Date(end);
      });
    }
    if (filters.personId) list = list.filter(e => e.personId === filters.personId);
    if (filters.category) list = list.filter(e => e.category === filters.category);
    if (query) {
      const q = query.toLowerCase();
      list = list.filter(e =>
        (e.personName || '').toLowerCase().includes(q) ||
        (e.category || '').toLowerCase().includes(q) ||
        (e.note || '').toLowerCase().includes(q) ||
        String(e.amount).includes(q)
      );
    }
    return list;
  }

  function groupByDate(list) {
    const groups = {};
    list.forEach(e => {
      if (!groups[e.date]) groups[e.date] = [];
      groups[e.date].push(e);
    });
    return Object.keys(groups).sort((a, b) => b.localeCompare(a)).map(date => ({
      date, items: groups[date].sort((a, b) => new Date(b.time || b.createdAt) - new Date(a.time || a.createdAt)),
      total: sum(groups[date])
    }));
  }

  // ---------------- Rendering: Expenses page (Daily Khoroj) ----------------

  let currentFilter = { range: 'month', personId: '', category: '' };

  async function renderPage() {
    const container = document.getElementById('page-content');
    container.innerHTML = `<div class="skeleton" style="height:80px;margin-bottom:14px;"></div>
      <div class="skeleton" style="height:60px;margin-bottom:8px;"></div>
      <div class="skeleton" style="height:60px;"></div>`;

    const members = await Family.getAll();
    const categories = await getAllCategories();
    const list = await search('', currentFilter);
    const total = sum(list);
    const grouped = groupByDate(list);

    const filterChips = ['today', 'week', 'month', 'lastMonth', 'year'];
    const filterLabels = { today: 'আজ', week: 'এই সপ্তাহ', month: 'এই মাস', lastMonth: 'গত মাস', year: 'এই বছর' };

    container.innerHTML = `
      <div class="card" style="padding:14px;">
        <div class="section-title" style="margin-bottom:8px;">মোট খরচ (${Utils.escapeHtml(filterLabels[currentFilter.range] || '')})
          <span style="color:var(--danger)">${Utils.fmtMoney(total)}</span>
        </div>
        <div class="chip-row" id="range-chips">
          ${filterChips.map(r => `<button class="chip ${currentFilter.range === r ? 'active' : ''}" data-range="${r}">${filterLabels[r]}</button>`).join('')}
        </div>
        <div class="chip-row" style="margin-top:10px;">
          <select id="filter-person" class="chip" style="border:1.5px solid var(--border);">
            <option value="">সব ব্যক্তি</option>
            ${members.map(m => `<option value="${m.id}" ${currentFilter.personId === m.id ? 'selected' : ''}>${Utils.escapeHtml(m.name)}</option>`).join('')}
          </select>
          <select id="filter-category" class="chip" style="border:1.5px solid var(--border);">
            <option value="">সব ক্যাটাগরি</option>
            ${categories.map(c => `<option value="${Utils.escapeHtml(c.name)}" ${currentFilter.category === c.name ? 'selected' : ''}>${Utils.escapeHtml(c.name)}</option>`).join('')}
          </select>
        </div>
      </div>
      <div id="expense-groups"></div>
    `;

    const groupsEl = document.getElementById('expense-groups');
    if (grouped.length === 0) {
      groupsEl.innerHTML = `<div class="empty-state"><div class="icon">🧾</div><div class="title">কোনো খরচ পাওয়া যায়নি</div><div class="desc">নতুন খরচ যোগ করতে নিচের + বাটনে চাপুন</div></div>`;
    } else {
      groupsEl.innerHTML = grouped.map(g => `
        <div class="date-group-header"><span>${Utils.relativeDayLabel(g.date)}</span><span>${Utils.fmtMoney(g.total)}</span></div>
        <div class="card" style="padding:4px 12px;">
          ${g.items.map(e => expenseRowHtml(e)).join('')}
        </div>
      `).join('');
    }

    document.getElementById('range-chips').querySelectorAll('.chip').forEach(btn => {
      btn.addEventListener('click', () => { currentFilter.range = btn.dataset.range; renderPage(); });
    });
    document.getElementById('filter-person').addEventListener('change', (e) => { currentFilter.personId = e.target.value; renderPage(); });
    document.getElementById('filter-category').addEventListener('change', (e) => { currentFilter.category = e.target.value; renderPage(); });

    groupsEl.querySelectorAll('.list-row').forEach(row => {
      row.addEventListener('click', () => App.openExpenseDetail(row.dataset.id));
    });
  }

  function expenseRowHtml(e) {
    return `
      <div class="list-row" data-id="${e.id}" role="button" tabindex="0">
        <div class="avatar">${e.receipt ? '🧾' : (categoryIcon(e.category) || '💸')}</div>
        <div class="info">
          <div class="title">${Utils.escapeHtml(e.category)} · ${Utils.escapeHtml(e.personName || '')}</div>
          <div class="sub">${Utils.fmtTime(e.time || e.createdAt)}${e.note ? ' · ' + Utils.escapeHtml(e.note) : ''}</div>
        </div>
        <div class="amount negative">-${Utils.fmtMoney(e.amount)}</div>
      </div>`;
  }

  let categoryIconMap = null;
  function categoryIcon(name) {
    if (!categoryIconMap) {
      categoryIconMap = {};
      DEFAULT_CATEGORIES.forEach(c => categoryIconMap[c.name] = c.icon);
    }
    return categoryIconMap[name];
  }

  return {
    DEFAULT_CATEGORIES, PAYMENT_METHODS, seedDefaultCategoriesIfEmpty, getAllCategories, addCustomCategory,
    getAll, getById, add, update, remove, getByMonth, getToday, sum, search, groupByDate,
    renderPage, expenseRowHtml, categoryIcon, currentFilter
  };
})();
