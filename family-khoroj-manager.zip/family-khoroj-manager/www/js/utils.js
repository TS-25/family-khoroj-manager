/* ==========================================================================
   utils.js — shared helpers used across the whole app
   ========================================================================== */
'use strict';

const Utils = (() => {

  const BN_DIGITS = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  const BN_MONTHS = ['জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'];
  const BN_MONTHS_SHORT = ['জানু', 'ফেব্রু', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্ট', 'অক্টো', 'নভে', 'ডিসে'];
  const BN_DAYS = ['রবিবার', 'সোমবার', 'মঙ্গলবার', 'বুধবার', 'বৃহস্পতিবার', 'শুক্রবার', 'শনিবার'];

  function toBanglaDigits(input) {
    return String(input).replace(/[0-9]/g, d => BN_DIGITS[d]);
  }

  function useBanglaNumerals() {
    try { return Settings.get('numeralStyle', 'bn') !== 'en'; } catch (e) { return true; }
  }

  function fmtNumber(n, decimals = 0) {
    n = Number(n) || 0;
    let out = n.toLocaleString('en-IN', { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
    return useBanglaNumerals() ? toBanglaDigits(out) : out;
  }

  function fmtMoney(n, opts = {}) {
    const decimals = opts.decimals !== undefined ? opts.decimals : (Number(n) % 1 !== 0 ? 2 : 0);
    return `৳ ${fmtNumber(n, decimals)}`;
  }

  function fmtDateShort(dateStr) {
    const d = new Date(dateStr);
    const day = fmtNumber(d.getDate());
    const month = BN_MONTHS_SHORT[d.getMonth()];
    return `${day} ${month}`;
  }

  function fmtDateLong(dateStr) {
    const d = new Date(dateStr);
    const day = fmtNumber(d.getDate());
    const month = BN_MONTHS[d.getMonth()];
    const year = fmtNumber(d.getFullYear());
    return `${day} ${month} ${year}`;
  }

  function fmtDayName(dateStr) {
    const d = new Date(dateStr);
    return BN_DAYS[d.getDay()];
  }

  function fmtTime(dateStr) {
    const d = new Date(dateStr);
    let h = d.getHours();
    const m = d.getMinutes();
    const ampm = h >= 12 ? 'PM' : 'AM';
    h = h % 12; if (h === 0) h = 12;
    const mm = String(m).padStart(2, '0');
    return `${fmtNumber(h)}:${fmtNumber(mm)} ${ampm}`;
  }

  function isSameDay(a, b) {
    const da = new Date(a), db = new Date(b);
    return da.getFullYear() === db.getFullYear() && da.getMonth() === db.getMonth() && da.getDate() === db.getDate();
  }

  function relativeDayLabel(dateStr) {
    const today = new Date(); today.setHours(0, 0, 0, 0);
    const d = new Date(dateStr); d.setHours(0, 0, 0, 0);
    const diffDays = Math.round((today - d) / 86400000);
    if (diffDays === 0) return 'আজ';
    if (diffDays === 1) return 'গতকাল';
    if (diffDays === 2) return 'পরশু';
    return `${fmtDateLong(dateStr)}, ${fmtDayName(dateStr)}`;
  }

  function todayISO() {
    const d = new Date();
    d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
    return d.toISOString().slice(0, 10);
  }

  function nowISO() { return new Date().toISOString(); }

  function monthKey(dateStr) {
    const d = new Date(dateStr);
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
  }

  function currentMonthKey() { return monthKey(new Date().toISOString()); }

  function uuid() {
    if (crypto && crypto.randomUUID) return crypto.randomUUID();
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
      const r = Math.random() * 16 | 0;
      const v = c === 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }

  function debounce(fn, wait = 300) {
    let t;
    return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), wait); };
  }

  function escapeHtml(str) {
    if (str === null || str === undefined) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function toast(message, type = 'default', duration = 2600) {
    const container = document.getElementById('toast-container');
    if (!container) return;
    const el = document.createElement('div');
    el.className = `toast ${type}`;
    el.textContent = message;
    container.appendChild(el);
    setTimeout(() => {
      el.style.transition = 'opacity .25s ease, transform .25s ease';
      el.style.opacity = '0';
      el.style.transform = 'translateY(-6px)';
      setTimeout(() => el.remove(), 260);
    }, duration);
  }

  function confirmDialog({ title = 'নিশ্চিত করুন', message = '', okText = 'নিশ্চিত করুন', danger = true } = {}) {
    return new Promise((resolve) => {
      const overlay = document.getElementById('confirm-overlay');
      document.getElementById('confirm-title').textContent = title;
      document.getElementById('confirm-message').textContent = message;
      const okBtn = document.getElementById('confirm-ok-btn');
      const cancelBtn = document.getElementById('confirm-cancel-btn');
      okBtn.textContent = okText;
      okBtn.className = 'btn ' + (danger ? 'btn-danger' : 'btn-primary');
      overlay.classList.remove('hidden');

      function cleanup(result) {
        overlay.classList.add('hidden');
        okBtn.removeEventListener('click', onOk);
        cancelBtn.removeEventListener('click', onCancel);
        resolve(result);
      }
      function onOk() { cleanup(true); }
      function onCancel() { cleanup(false); }
      okBtn.addEventListener('click', onOk);
      cancelBtn.addEventListener('click', onCancel);
    });
  }

  function validateAmount(value) {
    const n = parseFloat(value);
    if (value === '' || value === null || value === undefined) return { valid: false, msg: 'দয়া করে পরিমাণ লিখুন।' };
    if (isNaN(n)) return { valid: false, msg: 'দয়া করে সঠিক পরিমাণ লিখুন।' };
    if (n <= 0) return { valid: false, msg: 'পরিমাণ ০ এর বেশি হতে হবে।' };
    if (n > 100000000) return { valid: false, msg: 'পরিমাণটি অনেক বেশি মনে হচ্ছে।' };
    return { valid: true, value: n };
  }

  function startEndOfRange(range) {
    const now = new Date();
    let start, end;
    end = new Date(now); end.setHours(23, 59, 59, 999);
    if (range === 'today') {
      start = new Date(now); start.setHours(0, 0, 0, 0);
    } else if (range === 'yesterday') {
      start = new Date(now); start.setDate(start.getDate() - 1); start.setHours(0, 0, 0, 0);
      end = new Date(start); end.setHours(23, 59, 59, 999);
    } else if (range === 'week') {
      start = new Date(now); const day = start.getDay();
      start.setDate(start.getDate() - day); start.setHours(0, 0, 0, 0);
    } else if (range === 'month') {
      start = new Date(now.getFullYear(), now.getMonth(), 1);
    } else if (range === 'lastMonth') {
      start = new Date(now.getFullYear(), now.getMonth() - 1, 1);
      end = new Date(now.getFullYear(), now.getMonth(), 0, 23, 59, 59, 999);
    } else if (range === 'year') {
      start = new Date(now.getFullYear(), 0, 1);
    } else {
      start = new Date(0);
    }
    return { start: start.toISOString(), end: end.toISOString() };
  }

  function compressImage(file, maxDim = 900, quality = 0.7) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
          let { width, height } = img;
          if (width > height && width > maxDim) { height = height * (maxDim / width); width = maxDim; }
          else if (height > maxDim) { width = width * (maxDim / height); height = maxDim; }
          const canvas = document.createElement('canvas');
          canvas.width = width; canvas.height = height;
          const ctx = canvas.getContext('2d');
          ctx.drawImage(img, 0, 0, width, height);
          resolve(canvas.toDataURL('image/jpeg', quality));
        };
        img.onerror = reject;
        img.src = e.target.result;
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }

  function downloadBlob(blob, filename) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = filename;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
  }

  const PERSON_ICONS = ['👨', '👩', '👦', '👧', '👴', '👵', '🧑', '👶'];
  const MEMBER_COLORS = ['#2E7D5B', '#C77D2A', '#4A6FA5', '#B84C6F', '#7A5CC8', '#3E9C8D', '#C24E4E', '#5E8B3B'];

  return {
    toBanglaDigits, fmtNumber, fmtMoney, fmtDateShort, fmtDateLong, fmtDayName, fmtTime,
    isSameDay, relativeDayLabel, todayISO, nowISO, monthKey, currentMonthKey,
    uuid, debounce, escapeHtml, toast, confirmDialog, validateAmount, startEndOfRange,
    compressImage, downloadBlob, BN_MONTHS, BN_MONTHS_SHORT, BN_DAYS, PERSON_ICONS, MEMBER_COLORS
  };
})();
