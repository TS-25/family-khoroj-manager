/* ==========================================================================
   reports.js — Statistics & charts (pie / bar / line) using Chart.js
   ========================================================================== */
'use strict';

const Reports = (() => {

  let charts = {};
  let currentRange = 'month';

  const CHART_COLORS = ['#2E7D5B', '#C77D2A', '#4A6FA5', '#B84C6F', '#7A5CC8', '#3E9C8D', '#C24E4E', '#5E8B3B', '#8B8B3B', '#3B6B8B'];

  function destroyCharts() {
    Object.values(charts).forEach(c => c && c.destroy());
    charts = {};
  }

  async function renderPage() {
    const container = document.getElementById('page-content');
    container.innerHTML = `<div class="skeleton" style="height:220px;margin-bottom:14px;"></div>`;

    const { start, end } = Utils.startEndOfRange(currentRange);
    const allExpenses = await Expenses.getAll();
    const expenses = allExpenses.filter(e => {
      const d = new Date(e.date + 'T12:00:00');
      return d >= new Date(start) && d <= new Date(end);
    });
    const total = Expenses.sum(expenses);

    const byCategory = {};
    expenses.forEach(e => { byCategory[e.category] = (byCategory[e.category] || 0) + Number(e.amount); });
    const catEntries = Object.entries(byCategory).sort((a, b) => b[1] - a[1]);

    const byPerson = {};
    expenses.forEach(e => { const k = e.personName || 'অজানা'; byPerson[k] = (byPerson[k] || 0) + Number(e.amount); });
    const personEntries = Object.entries(byPerson).sort((a, b) => b[1] - a[1]);

    const trend = buildTrend(expenses, currentRange);

    const rangeLabels = { today: 'আজ', week: 'এই সপ্তাহ', month: 'এই মাস', lastMonth: 'গত মাস', year: 'এই বছর' };

    container.innerHTML = `
      <div class="chip-row" style="margin-bottom:14px;">
        ${Object.keys(rangeLabels).map(r => `<button class="chip ${currentRange === r ? 'active' : ''}" data-range="${r}">${rangeLabels[r]}</button>`).join('')}
      </div>

      <div class="balance-hero">
        <div class="label">মোট খরচ (${rangeLabels[currentRange]})</div>
        <div class="amount">${Utils.fmtMoney(total)}</div>
      </div>

      ${expenses.length === 0 ? `<div class="empty-state"><div class="icon">📊</div><div class="title">এই সময়ে কোনো খরচ নেই</div></div>` : `
      <div class="card">
        <div class="section-title">সবচেয়ে বেশি খরচ (ক্যাটাগরি)</div>
        <canvas id="chart-category-pie" height="220"></canvas>
      </div>

      <div class="card">
        <div class="section-title">খরচের প্রবণতা</div>
        <canvas id="chart-trend-line" height="200"></canvas>
      </div>

      <div class="card">
        <div class="section-title">ব্যক্তি অনুযায়ী খরচ</div>
        <canvas id="chart-person-bar" height="220"></canvas>
      </div>

      <div class="card">
        <div class="section-title">সেরা খরচের ক্যাটাগরি</div>
        ${catEntries.slice(0, 5).map(([cat, amt], i) => `
          <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;${i > 0 ? 'border-top:1px solid var(--border);' : ''}">
            <span>${Expenses.categoryIcon(cat) || '🏷️'} ${Utils.escapeHtml(cat)}</span>
            <b style="color:var(--danger);">${Utils.fmtMoney(amt)}</b>
          </div>`).join('')}
      </div>`}
    `;

    container.querySelectorAll('[data-range]').forEach(btn => {
      btn.addEventListener('click', () => { currentRange = btn.dataset.range; renderPage(); });
    });

    if (expenses.length > 0 && typeof Chart !== 'undefined') {
      destroyCharts();
      const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
      const textColor = isDark ? '#ECF1EE' : '#17201C';

      charts.pie = new Chart(document.getElementById('chart-category-pie'), {
        type: 'pie',
        data: {
          labels: catEntries.map(([c]) => c),
          datasets: [{ data: catEntries.map(([, v]) => v), backgroundColor: CHART_COLORS }]
        },
        options: { plugins: { legend: { position: 'bottom', labels: { color: textColor, font: { family: "'Noto Sans Bengali'" } } } } }
      });

      charts.line = new Chart(document.getElementById('chart-trend-line'), {
        type: 'line',
        data: {
          labels: trend.labels,
          datasets: [{ label: 'খরচ', data: trend.values, borderColor: '#2E7D5B', backgroundColor: 'rgba(46,125,91,0.15)', fill: true, tension: 0.35 }]
        },
        options: {
          plugins: { legend: { display: false } },
          scales: { x: { ticks: { color: textColor } }, y: { ticks: { color: textColor } } }
        }
      });

      charts.bar = new Chart(document.getElementById('chart-person-bar'), {
        type: 'bar',
        data: {
          labels: personEntries.map(([p]) => p),
          datasets: [{ label: 'খরচ', data: personEntries.map(([, v]) => v), backgroundColor: '#C77D2A', borderRadius: 6 }]
        },
        options: {
          plugins: { legend: { display: false } },
          scales: { x: { ticks: { color: textColor, font: { family: "'Noto Sans Bengali'" } } }, y: { ticks: { color: textColor } } }
        }
      });
    } else if (expenses.length > 0) {
      Utils.toast('চার্ট দেখতে প্রথমবার ইন্টারনেট সংযোগ প্রয়োজন।', 'warning');
    }
  }

  function buildTrend(expenses, range) {
    const map = {};
    expenses.forEach(e => { map[e.date] = (map[e.date] || 0) + Number(e.amount); });
    const dates = Object.keys(map).sort();
    return {
      labels: dates.map(d => Utils.fmtDateShort(d)),
      values: dates.map(d => map[d])
    };
  }

  return { renderPage, destroyCharts };
})();
