/* ==========================================================================
   debts.js — Loan / debt tracking (পাব / দেব)
   ========================================================================== */
'use strict';

const Debts = (() => {

  // type: 'receivable' (আমি পাব) | 'payable' (আমি দেব)

  async function getAll() {
    const list = await DB.getAll('debts');
    return list.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  }

  async function getById(id) { return DB.get('debts', id); }

  async function add({ personName, amount, type, note = '' }) {
    personName = (personName || '').trim();
    if (!personName) throw new Error('ব্যক্তির নাম আবশ্যক।');
    const now = Utils.nowISO();
    const record = {
      id: Utils.uuid(), personName, type, note,
      originalAmount: Number(amount), remainingAmount: Number(amount),
      settled: false, history: [{ date: now, amount: Number(amount), type: 'create' }],
      createdAt: now, updatedAt: now
    };
    await DB.put('debts', record);
    return record;
  }

  async function addPayment(id, amount) {
    const existing = await DB.get('debts', id);
    if (!existing) throw new Error('তথ্য পাওয়া যায়নি।');
    const remaining = Math.max(0, existing.remainingAmount - Number(amount));
    const updated = {
      ...existing, remainingAmount: remaining, settled: remaining <= 0,
      history: [...(existing.history || []), { date: Utils.nowISO(), amount: Number(amount), type: 'payment' }],
      updatedAt: Utils.nowISO()
    };
    await DB.put('debts', updated);
    return updated;
  }

  async function markPaid(id) {
    const existing = await DB.get('debts', id);
    if (!existing) throw new Error('তথ্য পাওয়া যায়নি।');
    const updated = { ...existing, remainingAmount: 0, settled: true, updatedAt: Utils.nowISO() };
    await DB.put('debts', updated);
    return updated;
  }

  async function remove(id) { await DB.remove('debts', id); }

  function sumRemaining(list) { return list.reduce((s, d) => s + Number(d.remainingAmount || 0), 0); }

  async function renderPage() {
    const container = document.getElementById('page-content');
    const all = await getAll();
    const receivable = all.filter(d => d.type === 'receivable' && !d.settled);
    const payable = all.filter(d => d.type === 'payable' && !d.settled);
    const settled = all.filter(d => d.settled);

    container.innerHTML = `
      <div class="stat-grid">
        <div class="stat-card income"><div class="s-label">আমি পাব</div><div class="s-value">${Utils.fmtMoney(sumRemaining(receivable))}</div></div>
        <div class="stat-card expense"><div class="s-label">আমি দেব</div><div class="s-value">${Utils.fmtMoney(sumRemaining(payable))}</div></div>
      </div>
      <div class="btn-block-row" style="margin-bottom:14px;">
        <button class="btn btn-primary" id="add-receivable-btn">+ পাব যোগ করুন</button>
        <button class="btn btn-secondary" id="add-payable-btn">+ দেব যোগ করুন</button>
      </div>
      <div class="section-title">পাব (${Utils.fmtNumber(receivable.length)})</div>
      <div id="receivable-list"></div>
      <div class="section-title" style="margin-top:18px;">দেব (${Utils.fmtNumber(payable.length)})</div>
      <div id="payable-list"></div>
      ${settled.length ? `<div class="section-title" style="margin-top:18px;">পরিশোধিত</div><div id="settled-list"></div>` : ''}
    `;

    renderDebtList('receivable-list', receivable);
    renderDebtList('payable-list', payable);
    if (settled.length) renderDebtList('settled-list', settled, true);

    document.getElementById('add-receivable-btn').addEventListener('click', () => openDebtForm('receivable'));
    document.getElementById('add-payable-btn').addEventListener('click', () => openDebtForm('payable'));
  }

  function renderDebtList(elId, list, isSettled = false) {
    const el = document.getElementById(elId);
    if (!el) return;
    if (list.length === 0) {
      el.innerHTML = `<div class="empty-state" style="padding:20px;"><div class="desc">কোনো তথ্য নেই</div></div>`;
      return;
    }
    el.innerHTML = `<div class="card" style="padding:4px 12px;">${list.map(d => `
      <div class="list-row" data-id="${d.id}">
        <div class="avatar">${d.type === 'receivable' ? '⬇️' : '⬆️'}</div>
        <div class="info">
          <div class="title">${Utils.escapeHtml(d.personName)}</div>
          <div class="sub">${d.note ? Utils.escapeHtml(d.note) + ' · ' : ''}${Utils.fmtDateLong(d.createdAt)}</div>
        </div>
        <div class="amount ${d.type === 'receivable' ? 'positive' : 'negative'}">${Utils.fmtMoney(isSettled ? d.originalAmount : d.remainingAmount)}</div>
      </div>`).join('')}</div>`;

    el.querySelectorAll('.list-row').forEach(row => {
      row.addEventListener('click', () => openDebtDetail(row.dataset.id));
    });
  }

  function openDebtForm(type) {
    const modalRoot = document.getElementById('modal-root');
    const label = type === 'receivable' ? 'যার কাছে টাকা পাবেন তার নাম' : 'যাকে টাকা দিতে হবে তার নাম';
    modalRoot.innerHTML = `
      <div class="modal-overlay" id="debt-modal">
        <div class="modal-sheet">
          <div class="modal-drag-handle"></div>
          <div class="modal-header"><h2>${type === 'receivable' ? 'পাব যোগ করুন' : 'দেব যোগ করুন'}</h2>
            <button class="icon-btn" id="close-debt-modal">✕</button></div>
          <div class="field"><label>${label}</label><input id="debt-person" type="text" placeholder="নাম লিখুন"></div>
          <div class="field"><label>পরিমাণ</label>
            <div class="amount-input-wrap"><span class="currency-sign">৳</span><input id="debt-amount" type="number" inputmode="decimal"></div></div>
          <div class="field"><label>নোট (ঐচ্ছিক)</label><input id="debt-note" type="text" placeholder="কারণ লিখুন"></div>
          <button class="btn btn-primary" id="save-debt-btn">সংরক্ষণ করুন</button>
        </div>
      </div>`;
    document.getElementById('close-debt-modal').addEventListener('click', () => modalRoot.innerHTML = '');
    document.getElementById('debt-modal').addEventListener('click', (e) => { if (e.target.id === 'debt-modal') modalRoot.innerHTML = ''; });
    document.getElementById('save-debt-btn').addEventListener('click', async () => {
      const personName = document.getElementById('debt-person').value.trim();
      const amount = document.getElementById('debt-amount').value;
      const note = document.getElementById('debt-note').value.trim();
      if (!personName) { Utils.toast('নাম লিখুন।', 'error'); return; }
      const v = Utils.validateAmount(amount);
      if (!v.valid) { Utils.toast(v.msg, 'error'); return; }
      await add({ personName, amount: v.value, type, note });
      modalRoot.innerHTML = '';
      Utils.toast('সংরক্ষণ করা হয়েছে', 'success');
      renderPage();
    });
  }

  async function openDebtDetail(id) {
    const d = await getById(id);
    if (!d) return;
    const modalRoot = document.getElementById('modal-root');
    modalRoot.innerHTML = `
      <div class="modal-overlay" id="debt-detail-modal">
        <div class="modal-sheet">
          <div class="modal-drag-handle"></div>
          <div class="modal-header"><h2>${Utils.escapeHtml(d.personName)}</h2><button class="icon-btn" id="close-debt-detail">✕</button></div>
          <div class="card">
            <div style="display:flex;justify-content:space-between;margin-bottom:6px;"><span style="color:var(--muted);">মূল পরিমাণ</span><b>${Utils.fmtMoney(d.originalAmount)}</b></div>
            <div style="display:flex;justify-content:space-between;margin-bottom:6px;"><span style="color:var(--muted);">বাকি</span><b>${Utils.fmtMoney(d.remainingAmount)}</b></div>
            <div style="display:flex;justify-content:space-between;"><span style="color:var(--muted);">অবস্থা</span><b>${d.settled ? 'পরিশোধিত' : 'বকেয়া'}</b></div>
          </div>
          ${!d.settled ? `
          <div class="btn-block-row" style="margin-bottom:10px;">
            <button class="btn btn-primary" id="add-payment-btn">আংশিক পরিশোধ</button>
            <button class="btn btn-secondary" id="mark-paid-btn">সম্পূর্ণ পরিশোধিত</button>
          </div>` : ''}
          <button class="btn btn-danger" id="delete-debt-btn">মুছে ফেলুন</button>
        </div>
      </div>`;
    document.getElementById('close-debt-detail').addEventListener('click', () => modalRoot.innerHTML = '');
    document.getElementById('debt-detail-modal').addEventListener('click', (e) => { if (e.target.id === 'debt-detail-modal') modalRoot.innerHTML = ''; });
    const payBtn = document.getElementById('add-payment-btn');
    if (payBtn) payBtn.addEventListener('click', async () => {
      const val = prompt('কত টাকা পরিশোধ হয়েছে?');
      if (val === null) return;
      const v = Utils.validateAmount(val);
      if (!v.valid) { Utils.toast(v.msg, 'error'); return; }
      await addPayment(id, v.value);
      modalRoot.innerHTML = '';
      Utils.toast('আপডেট করা হয়েছে', 'success');
      renderPage();
    });
    const paidBtn = document.getElementById('mark-paid-btn');
    if (paidBtn) paidBtn.addEventListener('click', async () => {
      const ok = await Utils.confirmDialog({ title: 'সম্পূর্ণ পরিশোধিত?', message: 'এই ঋণটি সম্পূর্ণ পরিশোধিত হিসেবে চিহ্নিত হবে।', okText: 'হ্যাঁ', danger: false });
      if (ok) { await markPaid(id); modalRoot.innerHTML = ''; Utils.toast('সম্পন্ন হয়েছে', 'success'); renderPage(); }
    });
    document.getElementById('delete-debt-btn').addEventListener('click', async () => {
      const ok = await Utils.confirmDialog({ title: 'মুছে ফেলবেন?', message: 'এই তথ্যটি স্থায়ীভাবে মুছে যাবে।', okText: 'মুছে ফেলুন' });
      if (ok) { await remove(id); modalRoot.innerHTML = ''; Utils.toast('মুছে ফেলা হয়েছে', 'success'); renderPage(); }
    });
  }

  return { getAll, getById, add, addPayment, markPaid, remove, sumRemaining, renderPage };
})();
